# CampusSolve — Project #21: Library Record Application

A **zero-dependency Python 3.10+** library management system engineered with a **3-tier architecture** (Presentation, Business Logic, and Persistence layers), strict defensive input validation, atomic JSON/CSV persistence with automatic corruption recovery, executive analytics with terminal visualizations, multi-format report exports, bulk CSV ingestion, and a comprehensive automated test suite.

---

## 1. 3-Tier System Architecture

```text
+-------------------------------------------------------------------+
| TIER 1: PRESENTATION LAYER (src/ui/)                              |
|  - cli.py           : Menu-driven interactive terminal interface   |
|  - terminal_utils.py: ANSI colors, validated input loops, tables, |
|                       pagination, ASCII bar charts                |
|  - gui.py           : Optional zero-dependency Tkinter GUI (--gui)|
+-------------------------------------------------------------------+
                                 |
                                 v
+-------------------------------------------------------------------+
| TIER 2: BUSINESS LOGIC ENGINE (src/services/)                     |
|  - validators.py         : Sanitization, ISBN-10/13, regex/ranges |
|  - library_service.py    : Book/Member CRUD, Issue/Return/Renew,  |
|                            5-loan limit, fines, threshold alerts  |
|  - analytics_service.py  : Executive KPIs, averages, trends       |
|  - import_export_service : Bulk CSV import + MD/CSV/TXT exports   |
|  - seed_service.py       : 48-record realistic dataset generator  |
+-------------------------------------------------------------------+
                                 |
                                 v
+-------------------------------------------------------------------+
| TIER 3: DATA & PERSISTENCE LAYER (src/models/, src/repositories/) |
|  - models/          : Book, Member, LoanTransaction dataclasses   |
|  - storage.py       : Atomic JSON + synchronized CSV persistence, |
|                       corruption quarantine, backup & restore     |
|  - audit_logger.py  : Persistent timestamped plain-text audit log |
+-------------------------------------------------------------------+
```

---

## 2. Features Implemented

### Core Features (Must-Have)
- **Interactive Terminal Interface**: Branded welcome screen, ANSI-formatted menus, fixed-width tables with column separators, and interactive pagination (`[N]ext`, `[P]rev`, `[A]ll`, `[Q]uit`).
- **Defensive Input Validation**: Centralized `prompt_validated` loops with ISBN-10/13 checksum verification, email/phone regex checks, date/year range enforcement, path-traversal protection, and CSV formula-injection neutralization.
- **Core Business Logic Engine**: Full Book & Member CRUD, Issue/Return/Renew workflows, 5-loan limit enforcement, duplicate active-loan prevention, stock tracking, and automated overdue fine calculation (`5.00/day`).
- **Local Data Persistence**: Atomic JSON (`data/library_state.json`) and synchronized CSV mirrors (`data/books.csv`, `data/members.csv`, `data/transactions.csv`). Automatically recovers from missing or corrupted files by quarantining broken JSON into `backups/` and initializing a clean template.
- **Record Query & Search**: Keyword and category/status filtering across books, members, and transactions.
- **Executive Summary Generation**: Totals, utilization rate, return & on-time rates, average overdue days, collected & pending fines, category breakdowns, top borrowed books, monthly issue trends, and ASCII bar charts.

### Stretch Features (Good-to-Have)
- **Multi-Format Summary Export**: Generates structured Markdown reports (`.md`), standardized CSV reports (`.csv`), and plain-text audit trail exports (`.txt`) inside `exports/`.
- **Threshold Warning Indicators**: Automated console warnings (`ANOMALY`, `CRITICAL`, `WARNING`) for overdue loans, upcoming due dates, out-of-stock/low-stock books, members at the 5-loan cap, and data integrity anomalies.
- **Bulk Dataset Import**: Legacy CSV bulk importer for books and members (`data/sample_legacy_import.csv` included) with strict row-by-row validation and detailed error log generation in `logs/`.
- **Optional Desktop GUI**: Lightweight Tkinter interface (`python main.py --gui` or Menu Option `[8]`) reusing the exact same Tier 2 services.

---

## 3. Quick Start (Zero External Dependencies)

Requires **Python 3.10+** (uses Standard Library only).

```bash
# 1. Launch the primary interactive Terminal CLI (auto-seeds 48 sample records on first run)
python main.py

# 2. Print a non-interactive Executive Summary & Threshold Warnings snapshot
python main.py --summary

# 3. Reset and re-seed the 48-record realistic sample dataset
python main.py --reseed

# 4. Launch the optional Tkinter Desktop GUI
python main.py --gui
```

---

## 4. Running Automated Tests

Run the entire `unittest` suite (unit, persistence, bulk import, analytics, and end-to-end CLI integration tests):

```bash
python -m unittest discover -s tests -v
```

---

## 5. Demo Walkthrough

1. Run `python main.py` to view the branded welcome banner, active threshold alerts, and menu.
2. Select `[1] Book Catalog -> [2] Add New Book` and enter an invalid ISBN (e.g., `123`) to observe the centralized defensive validation loop, then provide a valid ISBN (`9780135957059`).
3. Select `[3] Circulation Desk -> [1] Issue Book` and attempt to issue a book to `MEM-001` (already at the 5-loan limit) to verify business rule enforcement, then issue to `MEM-002`.
4. Select `[4] Executive Summary & Visual Analytics` to inspect computed KPIs, category breakdowns, and ASCII bar charts.
5. Exit (`[0]`), relaunch `python main.py`, and verify that your newly added book and loan persist across restarts.
6. Select `[6] -> [1]/[2]/[3]` to export Markdown, CSV, and Audit Trail reports into `exports/`, or `[5]` to test Bulk CSV Import against `data/sample_legacy_import.csv`.
