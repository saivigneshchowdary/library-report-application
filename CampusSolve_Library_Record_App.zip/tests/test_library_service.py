"""Unit tests for core business logic rules in LibraryService."""

from datetime import date, timedelta
from pathlib import Path
import tempfile
import unittest

from src.config import DEFAULT_CONFIG
from src.exceptions import BusinessRuleError, DuplicateRecordError
from src.repositories import AuditLogger, LibraryRepository
from src.services import LibraryService


class TestLibraryService(unittest.TestCase):
    """Verify CRUD, loan limits, stock rules, overdue fines, renewals, and alerts."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        repo = LibraryRepository(self.root)
        logger = AuditLogger(repo.logs_dir / DEFAULT_CONFIG.audit_log_filename)
        self.service = LibraryService(repo, logger)

        self.book = self.service.add_book(
            isbn="9780132350884",
            title="Clean Code",
            author="Robert C. Martin",
            category="Software Engineering",
            publication_year=2008,
            total_copies=2,
            shelf_location="SE-A1",
        )
        self.member = self.service.register_member(
            name="Aarav Sharma",
            email="aarav@campus.edu",
            phone="9876543210",
            department="Computer Science",
            membership_type="Student",
        )

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_duplicate_isbn_and_email_rejected(self) -> None:
        with self.assertRaises(DuplicateRecordError):
            self.service.add_book("978-0-13-235088-4", "Dup", "Author", "Cat", 2020, 1)
        with self.assertRaises(DuplicateRecordError):
            self.service.register_member("Other", "AARAV@campus.edu", "9876543211", "CS")

    def test_issue_and_return_updates_inventory_and_computes_fine(self) -> None:
        issue_dt = date(2026, 1, 1)
        txn = self.service.issue_book(self.member.member_id, self.book.book_id, loan_days=14, issue_date=issue_dt)
        self.assertEqual(self.service.get_book(self.book.book_id).available_copies, 1)
        self.assertEqual(txn.due_date, "2026-01-15")

        # Return 3 days late -> fine = 3 * 5.0 = 15.0
        returned = self.service.return_book(txn.record_id, return_date=date(2026, 1, 18))
        self.assertEqual(returned.status, "RETURNED")
        self.assertEqual(returned.fine_amount, 15.0)
        self.assertEqual(self.service.get_book(self.book.book_id).available_copies, 2)

    def test_cannot_delete_book_or_deactivate_member_with_active_loan(self) -> None:
        self.service.issue_book(self.member.member_id, self.book.book_id)
        with self.assertRaises(BusinessRuleError):
            self.service.delete_book(self.book.book_id)
        with self.assertRaises(BusinessRuleError):
            self.service.update_member(self.member.member_id, active=False)

    def test_five_loan_limit_and_duplicate_active_loan_enforced(self) -> None:
        valid_isbns = [
            "9780201633610",
            "9780131103627",
            "9780262033848",
            "9781491957660",
            "9781449355739",
        ]
        # Duplicate active loan of same book blocked
        self.service.issue_book(self.member.member_id, self.book.book_id)
        with self.assertRaises(BusinessRuleError):
            self.service.issue_book(self.member.member_id, self.book.book_id)

        # Issue 4 more distinct books -> reaches cap of 5
        extra_books = []
        for idx, isbn in enumerate(valid_isbns):
            extra_books.append(
                self.service.add_book(isbn, f"Book {idx}", "Author", "CS", 2020, 2)
            )
        for bk in extra_books[:4]:
            self.service.issue_book(self.member.member_id, bk.book_id)

        # 6th loan must be rejected
        with self.assertRaises(BusinessRuleError):
            self.service.issue_book(self.member.member_id, extra_books[4].book_id)

    def test_zero_stock_blocks_issue_and_triggers_warning(self) -> None:
        single_book = self.service.add_book("9780134685991", "Effective Java", "Joshua Bloch", "Java", 2018, 1)
        self.service.issue_book(self.member.member_id, single_book.book_id)

        other_member = self.service.register_member("Priya", "priya@campus.edu", "9123456789", "IT")
        with self.assertRaises(BusinessRuleError):
            self.service.issue_book(other_member.member_id, single_book.book_id)

        warnings = self.service.get_threshold_warnings()
        self.assertTrue(any(w.category == "STOCK" and w.entity_id == single_book.book_id for w in warnings))

    def test_renew_loan_limits(self) -> None:
        future_issue = date.today() - timedelta(days=2)
        txn = self.service.issue_book(self.member.member_id, self.book.book_id, loan_days=14, issue_date=future_issue)
        self.service.renew_loan(txn.record_id, extra_days=7)
        self.service.renew_loan(txn.record_id, extra_days=7)
        with self.assertRaises(BusinessRuleError):
            self.service.renew_loan(txn.record_id, extra_days=7)


if __name__ == "__main__":
    unittest.main()
