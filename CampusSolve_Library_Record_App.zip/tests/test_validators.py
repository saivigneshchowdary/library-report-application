"""Unit tests for defensive input validators and sanitization helpers."""

import unittest

from src.exceptions import ValidationError
from src.services.validators import (
    sanitize_text,
    validate_email,
    validate_isbn,
    validate_iso_date,
    validate_membership_type,
    validate_phone,
    validate_positive_int,
    validate_publication_year,
    validate_safe_export_filename,
    validate_shelf_location,
)


class TestValidators(unittest.TestCase):
    """Verify domain constraint enforcement across all input validators."""

    def test_sanitize_text_strips_control_chars_and_whitespace(self) -> None:
        self.assertEqual(sanitize_text("  Clean\x00 Code \n ", "Title"), "Clean Code")

    def test_sanitize_text_rejects_blank_when_required(self) -> None:
        with self.assertRaises(ValidationError):
            sanitize_text("   ", "Title")

    def test_validate_isbn_accepts_valid_isbn13_and_isbn10(self) -> None:
        self.assertEqual(validate_isbn("978-0-13-235088-4"), "9780132350884")
        self.assertEqual(validate_isbn("0-201-63361-2"), "0201633612")
        self.assertEqual(validate_isbn("080442957X"), "080442957X")

    def test_validate_isbn_rejects_bad_checksum(self) -> None:
        with self.assertRaises(ValidationError):
            validate_isbn("9780132350885")
        with self.assertRaises(ValidationError):
            validate_isbn("1234567890")

    def test_validate_positive_int_bounds(self) -> None:
        self.assertEqual(validate_positive_int("12", "Copies", 1, 100), 12)
        with self.assertRaises(ValidationError):
            validate_positive_int("0", "Copies", 1, 100)
        with self.assertRaises(ValidationError):
            validate_positive_int("abc", "Copies", 1, 100)

    def test_validate_publication_year_bounds(self) -> None:
        self.assertEqual(validate_publication_year("2024"), 2024)
        with self.assertRaises(ValidationError):
            validate_publication_year("1200")

    def test_validate_email_and_phone(self) -> None:
        self.assertEqual(validate_email("  User.Name@Campus.EDU "), "user.name@campus.edu")
        with self.assertRaises(ValidationError):
            validate_email("invalid-email")
        self.assertEqual(validate_phone("+91 98765-43210"), "+91 98765-43210")
        with self.assertRaises(ValidationError):
            validate_phone("12345")

    def test_validate_membership_type_and_shelf(self) -> None:
        self.assertEqual(validate_membership_type("faculty"), "Faculty")
        with self.assertRaises(ValidationError):
            validate_membership_type("Visitor")
        self.assertEqual(validate_shelf_location("se-a1"), "SE-A1")

    def test_validate_iso_date(self) -> None:
        parsed = validate_iso_date("2026-05-15", "Due Date")
        self.assertEqual(parsed.isoformat(), "2026-05-15")
        with self.assertRaises(ValidationError):
            validate_iso_date("15-05-2026", "Due Date")

    def test_safe_export_filename_blocks_traversal(self) -> None:
        self.assertEqual(validate_safe_export_filename("summary", ".md"), "summary.md")
        with self.assertRaises(ValidationError):
            validate_safe_export_filename("../secret.md", ".md")


if __name__ == "__main__":
    unittest.main()
