"""Tests for bulk CSV ingestion with row-level validation and error logs."""

import csv
from pathlib import Path
import tempfile
import unittest

from src.config import DEFAULT_CONFIG
from src.exceptions import ValidationError
from src.repositories import AuditLogger, LibraryRepository
from src.services import (
    AnalyticsService,
    ImportExportService,
    LibraryService,
    SeedService,
)


class TestBulkImport(unittest.TestCase):
    """Verify legacy CSV bulk import handles mixed valid and invalid rows."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        repo = LibraryRepository(self.root)
        logger = AuditLogger(repo.logs_dir / DEFAULT_CONFIG.audit_log_filename)
        self.library_service = LibraryService(repo, logger)
        SeedService.seed_application(self.library_service, overwrite=True)
        analytics = AnalyticsService(self.library_service)
        self.importer = ImportExportService(self.library_service, analytics)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_bulk_import_books_skips_invalid_rows_and_writes_error_log(self) -> None:
        sample_csv = self.library_service.repository.data_dir / "sample_legacy_import.csv"
        result = self.importer.bulk_import_books(sample_csv)

        self.assertEqual(result.total_rows, 7)
        self.assertEqual(result.imported_count, 3)
        self.assertEqual(result.skipped_count, 4)
        self.assertIsNotNone(result.error_log_path)
        self.assertTrue(result.error_log_path.exists())
        log_text = result.error_log_path.read_text(encoding="utf-8")
        self.assertIn("Row 5:", log_text)

    def test_bulk_import_members_validation(self) -> None:
        csv_file = self.root / "members_batch.csv"
        with csv_file.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["name", "email", "phone", "department", "membership_type"])
            writer.writerow(["Kiran Rao", "kiran.rao@campus.edu", "9988776655", "Physics", "Faculty"])
            writer.writerow(["Bad Email", "not-an-email", "9988776655", "Physics", "Student"])

        result = self.importer.bulk_import_members(csv_file)
        self.assertEqual(result.imported_count, 1)
        self.assertEqual(result.skipped_count, 1)

    def test_missing_required_headers_rejected(self) -> None:
        bad_csv = self.root / "bad.csv"
        bad_csv.write_text("title,author\nOnly Two Columns,Nobody\n", encoding="utf-8")
        with self.assertRaises(ValidationError):
            self.importer.bulk_import_books(bad_csv)


if __name__ == "__main__":
    unittest.main()
