"""End-to-end integration test simulating interactive CLI user journeys."""

from pathlib import Path
import tempfile
import unittest

from src.services import SeedService
from src.ui.cli import LibraryCLI, build_application_services
from src.ui.terminal_utils import TerminalUI


class TestCLIIntegration(unittest.TestCase):
    """Simulate real menu interactions including invalid inputs and restarts."""

    def test_end_to_end_cli_workflow_and_persistence(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            lib_svc, ana_svc, exp_svc = build_application_services(root)
            SeedService.seed_application(lib_svc, overwrite=True)

            # Scripted user journey:
            # 1 -> 2 (Add book with 1 bad ISBN then valid ISBN) -> 0 (back)
            # 4 (Executive summary)
            # 6 -> 1 (Export Markdown) -> 0 (back)
            # 0 (Exit)
            scripted_inputs = iter([
                "1",                  # Book Catalog menu
                "2",                  # Add New Book
                "bad-isbn",           # Invalid ISBN -> triggers validation retry!
                "9780135957059",      # Valid ISBN-13
                "The Pragmatic Programmer",
                "David Thomas",
                "Software Engineering",
                "2019",
                "3",
                "SE-A9",
                "0",                  # Back to main menu
                "4",                  # View Executive Summary & ASCII charts
                "6",                  # Import/Export menu
                "1",                  # Export Markdown
                "demo_report",        # Filename
                "0",                  # Back to main menu
                "0",                  # Save & Exit
            ])
            outputs: list[str] = []

            ui = TerminalUI(
                input_func=lambda _prompt: next(scripted_inputs),
                output_func=outputs.append,
                enable_color=False,
                interactive_pagination=False,
            )
            cli = LibraryCLI(lib_svc, ana_svc, exp_svc, ui=ui)
            cli.run()

            joined_output = "\n".join(outputs)
            self.assertIn("CampusSolve", joined_output)
            self.assertIn("[ERROR]", joined_output)
            self.assertIn("The Pragmatic Programmer", joined_output)
            self.assertIn("EXECUTIVE SUMMARY", joined_output)
            self.assertIn("Markdown report saved", joined_output)
            self.assertTrue((root / "exports" / "demo_report.md").exists())

            # Simulate fresh restart and verify newly added book persisted
            lib_svc_restarted, _, _ = build_application_services(root)
            matches = lib_svc_restarted.search_books(keyword="Pragmatic Programmer")
            self.assertEqual(len(matches), 1)
            self.assertEqual(matches[0].isbn, "9780135957059")


if __name__ == "__main__":
    unittest.main()
