"""Tests for executive analytics calculations and multi-format exports."""

from datetime import date
from pathlib import Path
import tempfile
import unittest

from src.config import DEFAULT_CONFIG
from src.repositories import AuditLogger, LibraryRepository
from src.services import (
    AnalyticsService,
    ImportExportService,
    LibraryService,
    SeedService,
)


class TestAnalyticsAndExports(unittest.TestCase):
    """Verify KPI accuracy and Markdown/CSV/Audit Log report generation."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        repo = LibraryRepository(self.root)
        logger = AuditLogger(repo.logs_dir / DEFAULT_CONFIG.audit_log_filename)
        self.library_service = LibraryService(repo, logger)
        SeedService.seed_application(self.library_service, overwrite=True)
        self.analytics = AnalyticsService(self.library_service)
        self.exporter = ImportExportService(self.library_service, self.analytics)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_executive_summary_metrics_and_warnings(self) -> None:
        summary = self.analytics.generate_executive_summary(reference_date=date.today())
        self.assertEqual(summary.total_titles, 18)
        self.assertEqual(summary.total_members, 12)
        self.assertEqual(summary.active_members, 11)
        self.assertEqual(summary.total_transactions, 18)
        self.assertEqual(summary.returned_loans, 3)
        self.assertEqual(summary.active_loans, 15)
        self.assertEqual(summary.overdue_loans, 3)
        self.assertEqual(summary.total_fines_collected, 20.0)
        self.assertGreater(summary.pending_estimated_fines, 0.0)
        self.assertEqual(summary.health_status, "CRITICAL")
        self.assertTrue(len(summary.category_breakdown) >= 5)

    def test_export_markdown_csv_and_audit_log(self) -> None:
        md_path = self.exporter.export_markdown_summary("test_summary.md")
        csv_path = self.exporter.export_csv_summary("test_summary.csv")
        txt_path = self.exporter.export_audit_log_report("test_audit.txt")

        self.assertTrue(md_path.exists())
        self.assertTrue(csv_path.exists())
        self.assertTrue(txt_path.exists())

        md_text = md_path.read_text(encoding="utf-8")
        self.assertIn("Executive Summary Report", md_text)
        self.assertIn("Threshold Warning Indicators", md_text)

        csv_text = csv_path.read_text(encoding="utf-8")
        self.assertIn("KPI,Utilization Rate (%)", csv_text)
        self.assertIn("CATEGORY,", csv_text)

        txt_text = txt_path.read_text(encoding="utf-8")
        self.assertIn("Audit Trail Export", txt_text)


if __name__ == "__main__":
    unittest.main()
