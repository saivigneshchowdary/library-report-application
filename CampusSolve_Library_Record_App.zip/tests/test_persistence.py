"""Tests for JSON/CSV persistence, corruption recovery, backups, and CSV safety."""

import json
from pathlib import Path
import tempfile
import unittest

from src.config import DEFAULT_CONFIG
from src.repositories import AuditLogger, LibraryRepository
from src.services import LibraryService


class TestPersistenceAndRecovery(unittest.TestCase):
    """Verify state survives restarts and recovers from missing or corrupted files."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.repo = LibraryRepository(self.root)
        self.logger = AuditLogger(self.repo.logs_dir / DEFAULT_CONFIG.audit_log_filename)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_json_and_csv_roundtrip_across_restarts(self) -> None:
        svc1 = LibraryService(self.repo, self.logger)
        book = svc1.add_book("9780132350884", "=Clean Code", "Robert Martin", "SE", 2008, 3)
        member = svc1.register_member("Rohan", "rohan@campus.edu", "9876543210", "CS")
        txn = svc1.issue_book(member.member_id, book.book_id)

        # Confirm CSV mirror files exist
        self.assertTrue(self.repo.books_csv_path.exists())
        self.assertTrue(self.repo.members_csv_path.exists())
        self.assertTrue(self.repo.transactions_csv_path.exists())

        # Reload with fresh repository/service simulating app restart
        repo2 = LibraryRepository(self.root)
        svc2 = LibraryService(repo2, self.logger)
        self.assertIn(book.book_id, svc2.state.books)
        self.assertEqual(svc2.get_book(book.book_id).title, "=Clean Code")
        self.assertEqual(svc2.get_book(book.book_id).available_copies, 2)
        self.assertIn(txn.record_id, svc2.state.transactions)

    def test_corrupted_json_quarantined_and_recovered(self) -> None:
        self.repo.state_path.write_text("{broken json!!!", encoding="utf-8")
        state = self.repo.load_state()
        self.assertEqual(len(state.books), 0)
        self.assertTrue(any("Recovered from corrupted JSON" in w for w in state.recovery_warnings))
        quarantined = list(self.repo.backups_dir.glob("corrupted_*.json"))
        self.assertEqual(len(quarantined), 1)
        # Active file should now be valid JSON
        parsed = json.loads(self.repo.state_path.read_text(encoding="utf-8"))
        self.assertIn("books", parsed)

    def test_csv_fallback_when_json_deleted(self) -> None:
        svc = LibraryService(self.repo, self.logger)
        book = svc.add_book("9780132350884", "+FormulaTitle", "Author Name", "SE", 2008, 2)
        self.repo.state_path.unlink()

        recovered_state = self.repo.load_state()
        self.assertIn(book.book_id, recovered_state.books)
        self.assertEqual(recovered_state.books[book.book_id].title, "+FormulaTitle")
        self.assertTrue(any("CSV storage" in w for w in recovered_state.recovery_warnings))

    def test_backup_and_restore(self) -> None:
        svc = LibraryService(self.repo, self.logger)
        svc.add_book("9780132350884", "Original Book", "Author", "SE", 2008, 2)
        backup = self.repo.create_backup("snapshot")

        svc.add_book("9780201633610", "Second Book", "Author", "SE", 1994, 1)
        self.assertEqual(len(svc.state.books), 2)

        self.repo.restore_backup(backup)
        svc.reload()
        self.assertEqual(len(svc.state.books), 1)


if __name__ == "__main__":
    unittest.main()
