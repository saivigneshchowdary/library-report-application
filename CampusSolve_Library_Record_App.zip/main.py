"""Main entry point for the CampusSolve Library Record Application."""

import argparse
from pathlib import Path
import sys

from src.config import resolve_project_root
from src.services import SeedService
from src.ui.cli import LibraryCLI, build_application_services


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse optional CLI flags for GUI mode, dataset seeding, or quick summary."""
    parser = argparse.ArgumentParser(
        description="CampusSolve — Library Record Application (Python 3.10+ CLI)"
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Launch the optional lightweight Tkinter GUI instead of the terminal CLI.",
    )
    parser.add_argument(
        "--reseed",
        action="store_true",
        help="Reset and populate the 48-record realistic sample dataset before starting.",
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="Print the executive analytics summary and threshold warnings, then exit.",
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        default=None,
        help="Optional custom project root directory for data/logs/exports/backups.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    """Bootstrap application services, seed initial data if empty, and launch UI."""
    if sys.version_info < (3, 10):
        print("Error: Python 3.10 or higher is required.", file=sys.stderr)
        return 1

    args = parse_args(argv)
    base_dir = args.data_root.resolve() if args.data_root else resolve_project_root()
    library_service, analytics_service, import_export_service = build_application_services(base_dir)

    if args.reseed:
        SeedService.seed_application(library_service, overwrite=True)
    else:
        SeedService.seed_application(library_service, overwrite=False)

    if args.summary:
        cli = LibraryCLI(library_service, analytics_service, import_export_service)
        cli.show_executive_summary()
        cli.show_threshold_warnings()
        return 0

    if args.gui:
        try:
            from src.ui.gui import launch_gui
        except Exception as exc:
            print(f"Unable to start Tkinter GUI ({exc}). Falling back to terminal CLI.")
        else:
            launch_gui(library_service, analytics_service, import_export_service)
            return 0

    cli = LibraryCLI(library_service, analytics_service, import_export_service)
    cli.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
