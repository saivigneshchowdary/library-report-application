"""Terminal formatting, centralized input wrappers, paginated tables, and ASCII charts."""

import os
import sys
from typing import Callable, Iterable, Sequence, TypeVar

from src.exceptions import ValidationError


T = TypeVar("T")


class _AnsiPalette:
    """ANSI escape sequences for terminal readability."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"


class CancelInput(Exception):
    """Raised internally when a user cancels out of an interactive prompt."""


class TerminalUI:
    """Reusable terminal I/O helper with ANSI styling, validation loops, and pagination."""

    def __init__(
        self,
        input_func: Callable[[str], str] = input,
        output_func: Callable[[str], None] = print,
        enable_color: bool | None = None,
        interactive_pagination: bool | None = None,
    ) -> None:
        self.input_func = input_func
        self.output_func = output_func
        if enable_color is None:
            is_tty = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
            no_color = bool(os.environ.get("NO_COLOR"))
            self.enable_color = is_tty and not no_color
        else:
            self.enable_color = enable_color

        if interactive_pagination is None:
            self.interactive_pagination = input_func is input and (
                hasattr(sys.stdin, "isatty") and sys.stdin.isatty()
            )
        else:
            self.interactive_pagination = interactive_pagination

        if self.enable_color and os.name == "nt":
            os.system("")  # Enable ANSI VT100 sequence processing on Windows consoles.

    def style(self, text: str, *codes: str) -> str:
        """Apply ANSI styling when color output is enabled."""
        if not self.enable_color or not codes:
            return text
        return f"{''.join(codes)}{text}{_AnsiPalette.RESET}"

    def print_line(self, text: str = "") -> None:
        """Print a line through the configured output sink."""
        self.output_func(text)

    def print_success(self, message: str) -> None:
        self.print_line(self.style(f"[OK] {message}", _AnsiPalette.GREEN, _AnsiPalette.BOLD))

    def print_warning(self, message: str) -> None:
        self.print_line(self.style(f"[WARN] {message}", _AnsiPalette.YELLOW, _AnsiPalette.BOLD))

    def print_error(self, message: str) -> None:
        self.print_line(self.style(f"[ERROR] {message}", _AnsiPalette.RED, _AnsiPalette.BOLD))

    def print_info(self, message: str) -> None:
        self.print_line(self.style(f"[INFO] {message}", _AnsiPalette.CYAN))

    def print_banner(self, title: str, subtitle: str) -> None:
        """Display a branded welcome banner."""
        width = 76
        border = "=" * width
        self.print_line(self.style(border, _AnsiPalette.CYAN, _AnsiPalette.BOLD))
        self.print_line(self.style(title.center(width), _AnsiPalette.CYAN, _AnsiPalette.BOLD))
        self.print_line(self.style(subtitle.center(width), _AnsiPalette.DIM))
        self.print_line(self.style(border, _AnsiPalette.CYAN, _AnsiPalette.BOLD))

    def print_section(self, heading: str) -> None:
        """Display a crisp section divider."""
        self.print_line()
        self.print_line(self.style(f"--- {heading} ---", _AnsiPalette.BLUE, _AnsiPalette.BOLD))

    def prompt_raw(self, prompt: str, allow_cancel: bool = True) -> str:
        """Read input and raise CancelInput if the user types 'cancel' or 'q!'."""
        suffix = " (or 'cancel')" if allow_cancel else ""
        value = self.input_func(f"{prompt}{suffix}: ")
        if allow_cancel and value.strip().lower() in {"cancel", "!q"}:
            raise CancelInput()
        return value

    def prompt_validated(
        self,
        prompt: str,
        validator: Callable[[str], T],
        allow_cancel: bool = True,
    ) -> T:
        """Loop until the user enters a value accepted by the supplied validator."""
        while True:
            raw = self.prompt_raw(prompt, allow_cancel=allow_cancel)
            try:
                return validator(raw)
            except ValidationError as exc:
                self.print_error(str(exc))

    def prompt_optional(
        self,
        prompt: str,
        validator: Callable[[str], T],
        default: T | None = None,
    ) -> T | None:
        """Prompt for an optional field; pressing Enter returns default."""
        default_hint = f" [Enter = keep '{default}']" if default is not None else " [Enter = skip]"
        while True:
            raw = self.input_func(f"{prompt}{default_hint}: ")
            if raw.strip().lower() in {"cancel", "!q"}:
                raise CancelInput()
            if not raw.strip():
                return default
            try:
                return validator(raw)
            except ValidationError as exc:
                self.print_error(str(exc))

    def prompt_confirm(self, prompt: str, default_yes: bool = False) -> bool:
        """Prompt for a yes/no confirmation."""
        hint = "[Y/n]" if default_yes else "[y/N]"
        while True:
            raw = self.input_func(f"{prompt} {hint}: ").strip().lower()
            if not raw:
                return default_yes
            if raw in {"y", "yes"}:
                return True
            if raw in {"n", "no"}:
                return False
            self.print_error("Please enter 'y' or 'n'.")

    def render_table(
        self,
        headers: Sequence[str],
        rows: Sequence[Sequence[object]],
        col_widths: Sequence[int] | None = None,
        page_size: int = 10,
        title: str = "",
    ) -> None:
        """Render fixed-width terminal tables with column separators and pagination."""
        if title:
            self.print_section(title)

        if not rows:
            self.print_info("No matching records found.")
            return

        widths = list(col_widths) if col_widths else self._compute_widths(headers, rows)
        separator = "+-" + "-+-".join("-" * w for w in widths) + "-+"
        header_line = "| " + " | ".join(self._clip(h, w) for h, w in zip(headers, widths)) + " |"

        total_rows = len(rows)
        total_pages = max(1, (total_rows + page_size - 1) // page_size)
        current_page = 0

        while True:
            start = current_page * page_size
            end = min(start + page_size, total_rows)
            page_rows = rows[start:end]

            self.print_line(separator)
            self.print_line(self.style(header_line, _AnsiPalette.BOLD))
            self.print_line(separator)
            for row in page_rows:
                formatted = "| " + " | ".join(self._clip(cell, w) for cell, w in zip(row, widths)) + " |"
                self.print_line(formatted)
            self.print_line(separator)
            self.print_line(
                self.style(
                    f"Showing {start + 1}-{end} of {total_rows} record(s) (Page {current_page + 1}/{total_pages})",
                    _AnsiPalette.DIM,
                )
            )

            if total_pages == 1 or not self.interactive_pagination:
                if total_pages > 1 and not self.interactive_pagination and end < total_rows:
                    current_page += 1
                    continue
                break

            nav = self.input_func("Pagination: [N]ext, [P]rev, [A]ll, or [Q]uit view: ").strip().lower()
            if nav in {"n", "next"} and current_page < total_pages - 1:
                current_page += 1
            elif nav in {"p", "prev"} and current_page > 0:
                current_page -= 1
            elif nav in {"a", "all"}:
                self.interactive_pagination = False
                if current_page < total_pages - 1:
                    current_page += 1
                else:
                    break
            elif nav in {"q", "quit", ""}:
                break
            else:
                self.print_warning("Invalid navigation option or already at boundary page.")

    def render_bar_chart(
        self,
        title: str,
        items: Iterable[tuple[str, int | float]],
        max_bar_width: int = 32,
    ) -> None:
        """Render a clean horizontal ASCII bar chart in the terminal."""
        data = list(items)
        self.print_section(title)
        if not data:
            self.print_info("No data points to chart.")
            return

        max_val = max(val for _, val in data) or 1
        label_width = min(24, max(len(str(label)) for label, _ in data))
        for label, value in data:
            scaled = int(round((value / max_val) * max_bar_width)) if value > 0 else 0
            bar = self.style("#" * max(1 if value > 0 else 0, scaled), _AnsiPalette.CYAN)
            clipped_label = self._clip(str(label), label_width)
            val_text = f"{value:.2f}" if isinstance(value, float) and not value.is_integer() else f"{int(value)}"
            self.print_line(f"  {clipped_label} | {bar:<{max_bar_width}} ({val_text})")

    @staticmethod
    def _clip(value: object, width: int) -> str:
        text = str(value).replace("\n", " ").replace("\r", " ")
        if len(text) <= width:
            return text.ljust(width)
        if width <= 3:
            return text[:width]
        return text[: width - 3] + "..."

    @staticmethod
    def _compute_widths(headers: Sequence[str], rows: Sequence[Sequence[object]]) -> list[int]:
        widths = [len(str(h)) for h in headers]
        for row in rows:
            for idx, cell in enumerate(row):
                if idx < len(widths):
                    widths[idx] = max(widths[idx], min(32, len(str(cell))))
        return widths
