"""Interactive menu-driven CLI application (Tier 1 Presentation Layer)."""

from datetime import date
from pathlib import Path

from src.config import DEFAULT_CONFIG, LibraryConfig
from src.exceptions import LibraryAppError
from src.repositories import LibraryRepository
from src.services import (
    AnalyticsService,
    ImportExportService,
    LibraryService,
    SeedService,
)
from src.services.validators import (
    sanitize_text,
    validate_email,
    validate_isbn,
    validate_iso_date,
    validate_membership_type,
    validate_phone,
    validate_positive_int,
    validate_publication_year,
    validate_shelf_location,
)
from src.ui.terminal_utils import CancelInput, TerminalUI


class LibraryCLI:
    """Menu-driven terminal interface orchestrating user workflows."""

    def __init__(
        self,
        library_service: LibraryService,
        analytics_service: AnalyticsService,
        import_export_service: ImportExportService,
        ui: TerminalUI | None = None,
        config: LibraryConfig = DEFAULT_CONFIG,
    ) -> None:
        self.library_service = library_service
        self.analytics_service = analytics_service
        self.import_export_service = import_export_service
        self.ui = ui or TerminalUI()
        self.config = config

    def run(self) -> None:
        """Start the interactive menu loop until the user chooses to exit."""
        self.ui.print_banner(
            f"{self.config.app_name} (v{self.config.version})",
            "Zero-Dependency Python 3.10+ | 3-Tier Architecture | JSON + CSV Persistence",
        )
        self._display_startup_notices()

        while True:
            self._print_main_menu()
            choice = self.ui.input_func("Select an option [0-8]: ").strip()
            try:
                if choice == "1":
                    self._menu_books()
                elif choice == "2":
                    self._menu_members()
                elif choice == "3":
                    self._menu_circulation()
                elif choice == "4":
                    self.show_executive_summary()
                elif choice == "5":
                    self.show_threshold_warnings()
                elif choice == "6":
                    self._menu_import_export_logs()
                elif choice == "7":
                    self._menu_backup_and_seed()
                elif choice == "8":
                    self._launch_gui_from_cli()
                elif choice == "0":
                    self.ui.print_success("All changes saved to JSON/CSV. Goodbye!")
                    break
                else:
                    self.ui.print_warning("Invalid selection. Please enter a number from 0 to 8.")
            except CancelInput:
                self.ui.print_info("Action cancelled. Returning to menu.")
            except LibraryAppError as exc:
                self.ui.print_error(str(exc))

    def _display_startup_notices(self) -> None:
        """Show any file recovery messages and active critical warnings on launch."""
        for msg in self.library_service.state.recovery_warnings:
            self.ui.print_warning(msg)

        warnings = self.library_service.get_threshold_warnings()
        critical_count = sum(1 for w in warnings if w.severity in {"CRITICAL", "ANOMALY"})
        warn_count = sum(1 for w in warnings if w.severity == "WARNING")
        if warnings:
            self.ui.print_warning(
                f"Active Threshold Alerts: {critical_count} critical/anomaly, {warn_count} warning(s). "
                "Select option [5] to inspect."
            )
        else:
            self.ui.print_success("System health normal: no overdue or stock threshold alerts.")

    def _print_main_menu(self) -> None:
        state = self.library_service.state
        self.ui.print_section(
            f"MAIN MENU (Books: {len(state.books)} | Members: {len(state.members)} | Loans: {len(state.transactions)})"
        )
        self.ui.print_line("  [1] Book Catalog Management (Add / Search / Update / Delete)")
        self.ui.print_line("  [2] Member Directory Management (Register / Search / Update)")
        self.ui.print_line("  [3] Circulation Desk (Issue / Return / Renew / View Loans)")
        self.ui.print_line("  [4] Executive Summary & Visual Analytics")
        self.ui.print_line("  [5] Threshold Warning Indicators & Integrity Check")
        self.ui.print_line("  [6] Bulk CSV Import, Multi-Format Reports & Audit Logs")
        self.ui.print_line("  [7] Backup, Restore & Sample Data Seeder")
        self.ui.print_line("  [8] Launch Optional Desktop GUI (Tkinter)")
        self.ui.print_line("  [0] Save & Exit")

    # ------------------------------------------------------------------
    # [1] Book Catalog Menu
    # ------------------------------------------------------------------
    def _menu_books(self) -> None:
        while True:
            self.ui.print_section("BOOK CATALOG MANAGEMENT")
            self.ui.print_line("  [1] List / Search / Filter Books")
            self.ui.print_line("  [2] Add New Book")
            self.ui.print_line("  [3] Update Book Details")
            self.ui.print_line("  [4] Delete Book")
            self.ui.print_line("  [0] Back to Main Menu")
            choice = self.ui.input_func("Book Menu [0-4]: ").strip()

            try:
                if choice == "1":
                    self._flow_search_books()
                elif choice == "2":
                    self._flow_add_book()
                elif choice == "3":
                    self._flow_update_book()
                elif choice == "4":
                    self._flow_delete_book()
                elif choice == "0":
                    return
                else:
                    self.ui.print_warning("Choose a valid option between 0 and 4.")
            except CancelInput:
                self.ui.print_info("Cancelled operation.")
            except LibraryAppError as exc:
                self.ui.print_error(str(exc))

    def _flow_search_books(self) -> None:
        keyword = self.ui.input_func("Keyword (title/author/ISBN/ID, blank=all): ").strip()
        categories = self.library_service.list_categories()
        if categories:
            self.ui.print_info(f"Available categories: {', '.join(categories)}")
        category = self.ui.input_func("Filter by category (blank=all): ").strip()
        avail_only = self.ui.prompt_confirm("Show available copies only?", default_yes=False)

        books = self.library_service.search_books(
            keyword=keyword,
            category=category,
            available_only=avail_only,
        )
        rows = [
            [
                b.book_id,
                b.isbn,
                b.title,
                b.author,
                b.category,
                b.publication_year,
                f"{b.available_copies}/{b.total_copies}",
                b.shelf_location,
            ]
            for b in books
        ]
        self.ui.render_table(
            headers=["ID", "ISBN", "Title", "Author", "Category", "Year", "Avail/Tot", "Shelf"],
            rows=rows,
            col_widths=[7, 13, 24, 18, 18, 4, 9, 7],
            page_size=self.config.page_size,
            title=f"Book Search Results ({len(books)})",
        )

    def _flow_add_book(self) -> None:
        self.ui.print_section("ADD NEW BOOK")
        isbn = self.ui.prompt_validated("ISBN (10 or 13 digits)", validate_isbn)
        title = self.ui.prompt_validated(
            "Book Title",
            lambda v: sanitize_text(v, "Title", min_length=1, max_length=140),
        )
        author = self.ui.prompt_validated(
            "Author Name",
            lambda v: sanitize_text(v, "Author", min_length=2, max_length=100),
        )
        category = self.ui.prompt_validated(
            "Category (e.g., Programming, Algorithms)",
            lambda v: sanitize_text(v, "Category", min_length=2, max_length=60),
        )
        year = self.ui.prompt_validated("Publication Year", validate_publication_year)
        copies = self.ui.prompt_validated(
            "Total Copies",
            lambda v: validate_positive_int(v, "Total Copies", min_value=1, max_value=500),
        )
        shelf = self.ui.prompt_optional("Shelf Location", validate_shelf_location, default="GEN-A1") or "GEN-A1"

        book = self.library_service.add_book(
            isbn=isbn,
            title=title,
            author=author,
            category=category,
            publication_year=year,
            total_copies=copies,
            shelf_location=shelf,
        )
        self.ui.print_success(f"Added book {book.book_id}: '{book.title}' ({book.total_copies} copies).")

    def _flow_update_book(self) -> None:
        book_id = self.ui.prompt_validated(
            "Enter Book ID to update (e.g., BK-001)",
            lambda v: sanitize_text(v, "Book ID", min_length=2, max_length=20),
        )
        existing = self.library_service.get_book(book_id)
        self.ui.print_info(f"Editing {existing.book_id}: '{existing.title}' by {existing.author}")

        title = self.ui.prompt_optional(
            "Title",
            lambda v: sanitize_text(v, "Title", min_length=1, max_length=140),
            default=existing.title,
        )
        author = self.ui.prompt_optional(
            "Author",
            lambda v: sanitize_text(v, "Author", min_length=2, max_length=100),
            default=existing.author,
        )
        category = self.ui.prompt_optional(
            "Category",
            lambda v: sanitize_text(v, "Category", min_length=2, max_length=60),
            default=existing.category,
        )
        year = self.ui.prompt_optional("Publication Year", validate_publication_year, default=existing.publication_year)
        copies = self.ui.prompt_optional(
            "Total Copies",
            lambda v: validate_positive_int(v, "Total Copies", min_value=1, max_value=500),
            default=existing.total_copies,
        )
        shelf = self.ui.prompt_optional("Shelf Location", validate_shelf_location, default=existing.shelf_location)

        updated = self.library_service.update_book(
            book_id=existing.book_id,
            title=title,
            author=author,
            category=category,
            publication_year=year,
            total_copies=copies,
            shelf_location=shelf,
        )
        self.ui.print_success(f"Updated {updated.book_id} ({updated.available_copies}/{updated.total_copies} available).")

    def _flow_delete_book(self) -> None:
        book_id = self.ui.prompt_validated(
            "Enter Book ID to delete",
            lambda v: sanitize_text(v, "Book ID", min_length=2, max_length=20),
        )
        book = self.library_service.get_book(book_id)
        if self.ui.prompt_confirm(f"Confirm deletion of {book.book_id} ('{book.title}')?"):
            removed = self.library_service.delete_book(book.book_id)
            self.ui.print_success(f"Deleted {removed.book_id} from catalog.")
        else:
            self.ui.print_info("Deletion aborted.")

    # ------------------------------------------------------------------
    # [2] Member Directory Menu
    # ------------------------------------------------------------------
    def _menu_members(self) -> None:
        while True:
            self.ui.print_section("MEMBER DIRECTORY MANAGEMENT")
            self.ui.print_line("  [1] List / Search / Filter Members")
            self.ui.print_line("  [2] Register New Member")
            self.ui.print_line("  [3] Update Member Profile / Active Status")
            self.ui.print_line("  [0] Back to Main Menu")
            choice = self.ui.input_func("Member Menu [0-3]: ").strip()

            try:
                if choice == "1":
                    self._flow_search_members()
                elif choice == "2":
                    self._flow_register_member()
                elif choice == "3":
                    self._flow_update_member()
                elif choice == "0":
                    return
                else:
                    self.ui.print_warning("Choose a valid option between 0 and 3.")
            except CancelInput:
                self.ui.print_info("Cancelled operation.")
            except LibraryAppError as exc:
                self.ui.print_error(str(exc))

    def _flow_search_members(self) -> None:
        keyword = self.ui.input_func("Keyword (ID/name/email/dept, blank=all): ").strip()
        tier = self.ui.input_func("Membership Type (Student/Faculty/Staff/Researcher, blank=all): ").strip()
        active_only = self.ui.prompt_confirm("Show active members only?", default_yes=False)

        members = self.library_service.search_members(
            keyword=keyword,
            membership_type=tier,
            active_only=active_only,
        )
        rows = [
            [
                m.member_id,
                m.name,
                m.membership_type,
                m.department,
                m.email,
                f"{self.library_service.get_member_active_loan_count(m.member_id)}/{m.max_loans}",
                "Active" if m.active else "Inactive",
            ]
            for m in members
        ]
        self.ui.render_table(
            headers=["ID", "Name", "Tier", "Department", "Email", "Loans", "Status"],
            rows=rows,
            col_widths=[8, 20, 10, 18, 24, 5, 8],
            page_size=self.config.page_size,
            title=f"Member Search Results ({len(members)})",
        )

    def _flow_register_member(self) -> None:
        self.ui.print_section("REGISTER NEW MEMBER")
        name = self.ui.prompt_validated(
            "Full Name",
            lambda v: sanitize_text(v, "Member Name", min_length=2, max_length=100),
        )
        email = self.ui.prompt_validated("Campus Email", validate_email)
        phone = self.ui.prompt_validated("Phone Number (10-15 digits)", validate_phone)
        department = self.ui.prompt_validated(
            "Department",
            lambda v: sanitize_text(v, "Department", min_length=2, max_length=80),
        )
        tier = self.ui.prompt_optional(
            "Membership Type (Student/Faculty/Staff/Researcher)",
            validate_membership_type,
            default="Student",
        ) or "Student"

        member = self.library_service.register_member(
            name=name,
            email=email,
            phone=phone,
            department=department,
            membership_type=tier,
        )
        self.ui.print_success(f"Registered {member.member_id}: {member.name} ({member.membership_type}).")

    def _flow_update_member(self) -> None:
        member_id = self.ui.prompt_validated(
            "Enter Member ID (e.g., MEM-001)",
            lambda v: sanitize_text(v, "Member ID", min_length=2, max_length=20),
        )
        existing = self.library_service.get_member(member_id)
        self.ui.print_info(f"Editing {existing.member_id}: {existing.name} (Active={existing.active})")

        name = self.ui.prompt_optional(
            "Name",
            lambda v: sanitize_text(v, "Member Name", min_length=2, max_length=100),
            default=existing.name,
        )
        phone = self.ui.prompt_optional("Phone", validate_phone, default=existing.phone)
        department = self.ui.prompt_optional(
            "Department",
            lambda v: sanitize_text(v, "Department", min_length=2, max_length=80),
            default=existing.department,
        )
        tier = self.ui.prompt_optional("Membership Type", validate_membership_type, default=existing.membership_type)
        toggle_active = self.ui.prompt_confirm(
            f"Keep member active? (Current: {'Yes' if existing.active else 'No'})",
            default_yes=existing.active,
        )

        updated = self.library_service.update_member(
            member_id=existing.member_id,
            name=name,
            phone=phone,
            department=department,
            membership_type=tier,
            active=toggle_active,
        )
        self.ui.print_success(f"Updated {updated.member_id} ({updated.name}, Active={updated.active}).")

    # ------------------------------------------------------------------
    # [3] Circulation Desk Menu
    # ------------------------------------------------------------------
    def _menu_circulation(self) -> None:
        while True:
            self.ui.print_section("CIRCULATION DESK (ISSUE / RETURN / RENEW)")
            self.ui.print_line("  [1] Issue Book to Member")
            self.ui.print_line("  [2] Return Book")
            self.ui.print_line("  [3] Renew Active Loan")
            self.ui.print_line("  [4] Query & View Loan Transactions")
            self.ui.print_line("  [0] Back to Main Menu")
            choice = self.ui.input_func("Circulation Menu [0-4]: ").strip()

            try:
                if choice == "1":
                    self._flow_issue_book()
                elif choice == "2":
                    self._flow_return_book()
                elif choice == "3":
                    self._flow_renew_loan()
                elif choice == "4":
                    self._flow_search_transactions()
                elif choice == "0":
                    return
                else:
                    self.ui.print_warning("Choose a valid option between 0 and 4.")
            except CancelInput:
                self.ui.print_info("Cancelled operation.")
            except LibraryAppError as exc:
                self.ui.print_error(str(exc))

    def _flow_issue_book(self) -> None:
        self.ui.print_section("ISSUE BOOK")
        member_id = self.ui.prompt_validated(
            "Member ID (e.g., MEM-002)",
            lambda v: sanitize_text(v, "Member ID", min_length=2, max_length=20),
        )
        book_id = self.ui.prompt_validated(
            "Book ID (e.g., BK-001)",
            lambda v: sanitize_text(v, "Book ID", min_length=2, max_length=20),
        )
        loan_days = self.ui.prompt_optional(
            "Loan Duration in Days (1-60)",
            lambda v: validate_positive_int(v, "Loan Duration", min_value=1, max_value=60),
            default=self.config.default_loan_days,
        )
        notes = self.ui.input_func("Optional notes (Enter=none): ").strip()

        txn = self.library_service.issue_book(
            member_id=member_id,
            book_id=book_id,
            loan_days=loan_days,
            notes=notes,
        )
        self.ui.print_success(
            f"Issued {txn.book_id} to {txn.member_id} under {txn.record_id}. Due date: {txn.due_date}."
        )

    def _flow_return_book(self) -> None:
        self.ui.print_section("RETURN BOOK")
        record_id = self.ui.prompt_validated(
            "Transaction ID (e.g., TXN-001)",
            lambda v: sanitize_text(v, "Transaction ID", min_length=2, max_length=20),
        )
        ret_date = self.ui.prompt_optional(
            "Return Date (YYYY-MM-DD)",
            lambda v: validate_iso_date(v, "Return Date"),
            default=date.today(),
        )
        notes = self.ui.input_func("Return notes (Enter=none): ").strip()

        txn = self.library_service.return_book(
            record_id=record_id,
            return_date=ret_date,
            notes=notes,
        )
        if txn.fine_amount > 0:
            self.ui.print_warning(
                f"Returned {txn.record_id} ({txn.book_id}). Overdue fine assessed: {txn.fine_amount:.2f}."
            )
        else:
            self.ui.print_success(f"Returned {txn.record_id} ({txn.book_id}) on time with 0.00 fine.")

    def _flow_renew_loan(self) -> None:
        record_id = self.ui.prompt_validated(
            "Transaction ID to renew (e.g., TXN-004)",
            lambda v: sanitize_text(v, "Transaction ID", min_length=2, max_length=20),
        )
        extra_days = self.ui.prompt_optional(
            f"Extension days (1-{self.config.max_renewal_days})",
            lambda v: validate_positive_int(
                v, "Extension Days", min_value=1, max_value=self.config.max_renewal_days
            ),
            default=self.config.max_renewal_days,
        )
        txn = self.library_service.renew_loan(record_id, extra_days=extra_days)
        self.ui.print_success(
            f"Renewed {txn.record_id}. New due date: {txn.due_date} (Renewal #{txn.renewal_count})."
        )

    def _flow_search_transactions(self) -> None:
        keyword = self.ui.input_func("Keyword (TXN/Book/Member, blank=all): ").strip()
        status = self.ui.input_func("Status filter (ISSUED / OVERDUE / RETURNED, blank=all): ").strip().upper()
        txns = self.library_service.search_transactions(keyword=keyword, status_filter=status)

        rows = []
        for txn in txns:
            book = self.library_service.state.books.get(txn.book_id)
            member = self.library_service.state.members.get(txn.member_id)
            eff_status = txn.effective_status()
            rows.append([
                txn.record_id,
                f"{txn.book_id} ({book.title[:16] if book else '?'})",
                f"{txn.member_id} ({member.name[:14] if member else '?'})",
                txn.issue_date,
                txn.due_date,
                txn.return_date or "-",
                eff_status,
                f"{txn.fine_amount:.2f}",
            ])

        self.ui.render_table(
            headers=["TXN ID", "Book", "Member", "Issued", "Due", "Returned", "Status", "Fine"],
            rows=rows,
            col_widths=[7, 22, 20, 10, 10, 10, 8, 6],
            page_size=self.config.page_size,
            title=f"Loan Transactions ({len(txns)})",
        )

    # ------------------------------------------------------------------
    # [4] Executive Summary & Visual Analytics
    # ------------------------------------------------------------------
    def show_executive_summary(self) -> None:
        """Display KPI tables, category breakdown, rankings, and ASCII trend charts."""
        summary = self.analytics_service.generate_executive_summary()
        self.ui.print_section(f"EXECUTIVE SUMMARY ({summary.generated_date}) | Health: {summary.health_status}")

        kpi_rows = [
            ["Catalog Titles", summary.total_titles],
            ["Total / Available / Issued Copies", f"{summary.total_copies} / {summary.available_copies} / {summary.issued_copies}"],
            ["Collection Utilization Rate", f"{summary.utilization_rate_pct:.2f}%"],
            ["Registered Members (Active / Total)", f"{summary.active_members} / {summary.total_members}"],
            ["Avg Active Loans per Active Member", f"{summary.avg_loans_per_active_member:.2f}"],
            ["Total Transactions (Active / Returned)", f"{summary.total_transactions} ({summary.active_loans} / {summary.returned_loans})"],
            ["Overdue Active Loans", summary.overdue_loans],
            ["Return Completion / On-Time Rate", f"{summary.return_rate_pct:.2f}% / {summary.on_time_return_rate_pct:.2f}%"],
            ["Avg Overdue Days (Late Loans)", f"{summary.avg_overdue_days:.2f} days"],
            ["Fines Collected / Pending Estimate", f"{summary.total_fines_collected:.2f} / {summary.pending_estimated_fines:.2f}"],
        ]
        self.ui.render_table(
            headers=["Executive KPI", "Value"],
            rows=kpi_rows,
            col_widths=[40, 26],
            page_size=20,
        )

        cat_rows = [
            [
                cat.category,
                cat.title_count,
                cat.total_copies,
                cat.available_copies,
                cat.issued_copies,
                cat.historical_loans,
            ]
            for cat in summary.category_breakdown
        ]
        self.ui.render_table(
            headers=["Category", "Titles", "Copies", "Avail", "Issued", "Total Loans"],
            rows=cat_rows,
            col_widths=[22, 6, 6, 6, 6, 11],
            page_size=self.config.page_size,
            title="Category Inventory & Circulation",
        )

        self.ui.render_bar_chart(
            "Historical Loans by Category",
            [(cat.category, cat.historical_loans) for cat in summary.category_breakdown],
        )

        if summary.monthly_issue_trend:
            self.ui.render_bar_chart("Monthly Issue Trend (YYYY-MM)", summary.monthly_issue_trend)

        if summary.top_borrowed_books:
            self.ui.render_table(
                headers=["Book ID", "Title", "Total Loans"],
                rows=summary.top_borrowed_books,
                col_widths=[10, 40, 12],
                page_size=5,
                title="Top 5 Most Borrowed Books",
            )

    # ------------------------------------------------------------------
    # [5] Threshold Warning Indicators
    # ------------------------------------------------------------------
    def show_threshold_warnings(self) -> None:
        """Render automated threshold alerts for overdue loans, stock, and anomalies."""
        warnings = self.library_service.get_threshold_warnings()
        if not warnings:
            self.ui.print_success("No threshold breaches or integrity anomalies detected.")
            return

        rows = [[w.severity, w.category, w.entity_id, w.message] for w in warnings]
        self.ui.render_table(
            headers=["Severity", "Category", "Entity", "Warning Message"],
            rows=rows,
            col_widths=[9, 10, 8, 55],
            page_size=self.config.page_size,
            title=f"Threshold Warning Indicators ({len(warnings)})",
        )

    # ------------------------------------------------------------------
    # [6] Import, Export & Audit Logs
    # ------------------------------------------------------------------
    def _menu_import_export_logs(self) -> None:
        while True:
            self.ui.print_section("IMPORT, MULTI-FORMAT EXPORTS & AUDIT LOGS")
            self.ui.print_line("  [1] Export Markdown Executive Report (.md)")
            self.ui.print_line("  [2] Export Standardized CSV Report (.csv)")
            self.ui.print_line("  [3] Export Plain-Text Audit Trail (.txt)")
            self.ui.print_line("  [4] View Recent Audit Log Events")
            self.ui.print_line("  [5] Bulk Import Books from Legacy CSV (with error log)")
            self.ui.print_line("  [6] Bulk Import Members from Legacy CSV (with error log)")
            self.ui.print_line("  [0] Back to Main Menu")
            choice = self.ui.input_func("Import/Export Menu [0-6]: ").strip()

            try:
                if choice == "1":
                    name = self.ui.input_func("Filename (Enter=auto timestamped): ").strip() or None
                    out_path = self.import_export_service.export_markdown_summary(name)
                    self.ui.print_success(f"Markdown report saved to: {out_path}")
                elif choice == "2":
                    name = self.ui.input_func("Filename (Enter=auto timestamped): ").strip() or None
                    out_path = self.import_export_service.export_csv_summary(name)
                    self.ui.print_success(f"CSV summary report saved to: {out_path}")
                elif choice == "3":
                    name = self.ui.input_func("Filename (Enter=auto timestamped): ").strip() or None
                    out_path = self.import_export_service.export_audit_log_report(name)
                    self.ui.print_success(f"Audit log report saved to: {out_path}")
                elif choice == "4":
                    recent = self.library_service.audit_logger.read_recent(limit=20)
                    self.ui.print_section(f"RECENT AUDIT EVENTS (Last {len(recent)})")
                    if not recent:
                        self.ui.print_info("Audit log is empty.")
                    for line in recent:
                        self.ui.print_line(f"  {line}")
                elif choice == "5":
                    self._flow_bulk_import("books")
                elif choice == "6":
                    self._flow_bulk_import("members")
                elif choice == "0":
                    return
                else:
                    self.ui.print_warning("Choose a valid option between 0 and 6.")
            except CancelInput:
                self.ui.print_info("Cancelled operation.")
            except LibraryAppError as exc:
                self.ui.print_error(str(exc))

    def _flow_bulk_import(self, entity_type: str) -> None:
        default_sample = self.library_service.repository.data_dir / "sample_legacy_import.csv"
        if entity_type == "books" and default_sample.exists():
            self.ui.print_info(f"Sample CSV available at: {default_sample}")
        raw_path = self.ui.prompt_validated(
            f"Path to {entity_type} CSV file",
            lambda v: sanitize_text(v, "CSV Path", min_length=1, max_length=260),
        )
        if entity_type == "books":
            result = self.import_export_service.bulk_import_books(Path(raw_path))
        else:
            result = self.import_export_service.bulk_import_members(Path(raw_path))

        self.ui.print_success(
            f"Bulk import finished: {result.imported_count}/{result.total_rows} row(s) imported, "
            f"{result.skipped_count} skipped."
        )
        if result.error_log_path:
            self.ui.print_warning(f"Detailed row-by-row error log written to: {result.error_log_path}")
            for err in result.errors[:5]:
                self.ui.print_line(f"  - {err}")
            if len(result.errors) > 5:
                self.ui.print_info(f"  ... and {len(result.errors) - 5} more errors in the log file.")

    # ------------------------------------------------------------------
    # [7] Backup, Restore & Sample Data Seeder
    # ------------------------------------------------------------------
    def _menu_backup_and_seed(self) -> None:
        while True:
            self.ui.print_section("BACKUP, RESTORE & SAMPLE DATA")
            self.ui.print_line("  [1] Create Manual JSON Backup Snapshot")
            self.ui.print_line("  [2] Restore State from Existing Backup")
            self.ui.print_line("  [3] Reset & Seed 48-Record Sample Dataset")
            self.ui.print_line("  [0] Back to Main Menu")
            choice = self.ui.input_func("Maintenance Menu [0-3]: ").strip()

            try:
                if choice == "1":
                    label = self.ui.input_func("Backup label (Enter='manual'): ").strip() or "manual"
                    backup_path = self.library_service.repository.create_backup(label)
                    self.library_service.audit_logger.log("CREATE_BACKUP", "LIBRARIAN", f"Saved {backup_path.name}")
                    self.ui.print_success(f"Backup saved to: {backup_path}")
                elif choice == "2":
                    backups = self.library_service.repository.list_backups()
                    if not backups:
                        self.ui.print_info("No backups found in backups/ directory.")
                        continue
                    for idx, path in enumerate(backups[:10], start=1):
                        self.ui.print_line(f"  [{idx}] {path.name}")
                    idx_selected = self.ui.prompt_validated(
                        f"Select backup number (1-{min(10, len(backups))})",
                        lambda v: validate_positive_int(
                            v, "Backup Index", min_value=1, max_value=min(10, len(backups))
                        ),
                    )
                    chosen = backups[idx_selected - 1]
                    if self.ui.prompt_confirm(f"Restore from '{chosen.name}'? Current state will be backed up first."):
                        self.library_service.repository.restore_backup(chosen)
                        self.library_service.reload()
                        self.library_service.audit_logger.log("RESTORE_BACKUP", "LIBRARIAN", f"Restored {chosen.name}")
                        self.ui.print_success(f"Restored state from {chosen.name}.")
                elif choice == "3":
                    if self.ui.prompt_confirm("Overwrite current records with the 48-record sample dataset?"):
                        SeedService.seed_application(self.library_service, overwrite=True)
                        self.ui.print_success("Sample dataset (18 books, 12 members, 18 loans) seeded successfully.")
                elif choice == "0":
                    return
                else:
                    self.ui.print_warning("Choose a valid option between 0 and 3.")
            except CancelInput:
                self.ui.print_info("Cancelled operation.")
            except LibraryAppError as exc:
                self.ui.print_error(str(exc))

    # ------------------------------------------------------------------
    # [8] Optional Tkinter GUI Launcher
    # ------------------------------------------------------------------
    def _launch_gui_from_cli(self) -> None:
        try:
            from src.ui.gui import launch_gui
        except Exception as exc:
            self.ui.print_error(f"Tkinter GUI is unavailable in this environment: {exc}")
            return
        self.ui.print_info("Launching Tkinter GUI window. Close the GUI window to return to CLI...")
        launch_gui(self.library_service, self.analytics_service, self.import_export_service)
        self.library_service.reload()
        self.ui.print_success("Returned to terminal CLI.")


def build_application_services(base_dir: Path | None = None) -> tuple[LibraryService, AnalyticsService, ImportExportService]:
    """Wire together Tier 3 (Repository/Audit) and Tier 2 (Services) cleanly."""
    from src.config import resolve_project_root
    from src.repositories import AuditLogger

    root = base_dir or resolve_project_root()
    repository = LibraryRepository(root)
    audit_logger = AuditLogger(repository.logs_dir / DEFAULT_CONFIG.audit_log_filename)
    library_service = LibraryService(repository=repository, audit_logger=audit_logger)
    analytics_service = AnalyticsService(library_service=library_service)
    import_export_service = ImportExportService(
        library_service=library_service,
        analytics_service=analytics_service,
    )
    return library_service, analytics_service, import_export_service
