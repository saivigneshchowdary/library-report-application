"""Optional lightweight Tkinter GUI layered cleanly on top of Tier 2 services."""

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from src.exceptions import LibraryAppError
from src.services import AnalyticsService, ImportExportService, LibraryService


class LibraryGUI:
    """Zero-dependency Tkinter desktop interface sharing the core business services."""

    def __init__(
        self,
        root: tk.Tk,
        library_service: LibraryService,
        analytics_service: AnalyticsService,
        import_export_service: ImportExportService,
    ) -> None:
        self.root = root
        self.library_service = library_service
        self.analytics_service = analytics_service
        self.import_export_service = import_export_service

        self.root.title("CampusSolve — Library Record Application (GUI View)")
        self.root.geometry("1040x640")
        self.root.minsize(880, 540)

        self._build_layout()
        self.refresh_all()

    def _build_layout(self) -> None:
        header = ttk.Frame(self.root, padding=10)
        header.pack(fill=tk.X)
        ttk.Label(
            header,
            text="CampusSolve — Library Record Application",
            font=("Segoe UI", 14, "bold"),
        ).pack(side=tk.LEFT)
        ttk.Button(header, text="Refresh All", command=self.refresh_all).pack(side=tk.RIGHT)

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        self.books_tab = ttk.Frame(self.notebook, padding=8)
        self.members_tab = ttk.Frame(self.notebook, padding=8)
        self.loans_tab = ttk.Frame(self.notebook, padding=8)
        self.analytics_tab = ttk.Frame(self.notebook, padding=8)

        self.notebook.add(self.books_tab, text="Books Catalog")
        self.notebook.add(self.members_tab, text="Members Directory")
        self.notebook.add(self.loans_tab, text="Circulation Desk")
        self.notebook.add(self.analytics_tab, text="Analytics & Alerts")

        self._build_books_tab()
        self._build_members_tab()
        self._build_loans_tab()
        self._build_analytics_tab()

    def _build_books_tab(self) -> None:
        toolbar = ttk.Frame(self.books_tab)
        toolbar.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(toolbar, text="Search:").pack(side=tk.LEFT)
        self.book_search_var = tk.StringVar()
        entry = ttk.Entry(toolbar, textvariable=self.book_search_var, width=32)
        entry.pack(side=tk.LEFT, padx=6)
        entry.bind("<Return>", lambda _e: self.refresh_books())
        ttk.Button(toolbar, text="Filter", command=self.refresh_books).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="+ Add Book", command=self._dialog_add_book).pack(side=tk.RIGHT)
        ttk.Button(toolbar, text="Bulk Import CSV", command=self._action_bulk_import_books).pack(side=tk.RIGHT, padx=6)

        cols = ("id", "isbn", "title", "author", "category", "year", "copies", "shelf")
        self.books_tree = ttk.Treeview(self.books_tab, columns=cols, show="headings")
        for col, text, width in [
            ("id", "Book ID", 75),
            ("isbn", "ISBN", 120),
            ("title", "Title", 240),
            ("author", "Author", 160),
            ("category", "Category", 140),
            ("year", "Year", 60),
            ("copies", "Avail/Total", 85),
            ("shelf", "Shelf", 80),
        ]:
            self.books_tree.heading(col, text=text)
            self.books_tree.column(col, width=width, anchor=tk.W)
        self.books_tree.pack(fill=tk.BOTH, expand=True)

    def _build_members_tab(self) -> None:
        toolbar = ttk.Frame(self.members_tab)
        toolbar.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(toolbar, text="Search:").pack(side=tk.LEFT)
        self.member_search_var = tk.StringVar()
        entry = ttk.Entry(toolbar, textvariable=self.member_search_var, width=32)
        entry.pack(side=tk.LEFT, padx=6)
        entry.bind("<Return>", lambda _e: self.refresh_members())
        ttk.Button(toolbar, text="Filter", command=self.refresh_members).pack(side=tk.LEFT)
        ttk.Button(toolbar, text="+ Register Member", command=self._dialog_add_member).pack(side=tk.RIGHT)

        cols = ("id", "name", "tier", "dept", "email", "loans", "status")
        self.members_tree = ttk.Treeview(self.members_tab, columns=cols, show="headings")
        for col, text, width in [
            ("id", "Member ID", 85),
            ("name", "Full Name", 180),
            ("tier", "Tier", 95),
            ("dept", "Department", 150),
            ("email", "Email", 220),
            ("loans", "Loans", 70),
            ("status", "Status", 80),
        ]:
            self.members_tree.heading(col, text=text)
            self.members_tree.column(col, width=width, anchor=tk.W)
        self.members_tree.pack(fill=tk.BOTH, expand=True)

    def _build_loans_tab(self) -> None:
        toolbar = ttk.Frame(self.loans_tab)
        toolbar.pack(fill=tk.X, pady=(0, 6))
        ttk.Button(toolbar, text="Issue Book", command=self._dialog_issue_book).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Return Selected Loan", command=self._action_return_selected).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Renew Selected Loan", command=self._action_renew_selected).pack(side=tk.LEFT)

        cols = ("txn", "book", "member", "issued", "due", "returned", "status", "fine")
        self.loans_tree = ttk.Treeview(self.loans_tab, columns=cols, show="headings")
        for col, text, width in [
            ("txn", "TXN ID", 80),
            ("book", "Book", 200),
            ("member", "Member", 170),
            ("issued", "Issued", 95),
            ("due", "Due", 95),
            ("returned", "Returned", 95),
            ("status", "Status", 90),
            ("fine", "Fine", 70),
        ]:
            self.loans_tree.heading(col, text=text)
            self.loans_tree.column(col, width=width, anchor=tk.W)
        self.loans_tree.pack(fill=tk.BOTH, expand=True)

    def _build_analytics_tab(self) -> None:
        toolbar = ttk.Frame(self.analytics_tab)
        toolbar.pack(fill=tk.X, pady=(0, 6))
        ttk.Button(toolbar, text="Export Markdown (.md)", command=self._export_md).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Export CSV (.csv)", command=self._export_csv).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(toolbar, text="Export Audit Log (.txt)", command=self._export_audit).pack(side=tk.LEFT)

        self.summary_text = tk.Text(self.analytics_tab, wrap=tk.WORD, font=("Consolas", 10))
        self.summary_text.pack(fill=tk.BOTH, expand=True)

    def refresh_all(self) -> None:
        self.refresh_books()
        self.refresh_members()
        self.refresh_loans()
        self.refresh_analytics()

    def refresh_books(self) -> None:
        self.books_tree.delete(*self.books_tree.get_children())
        for book in self.library_service.search_books(keyword=self.book_search_var.get()):
            self.books_tree.insert(
                "",
                tk.END,
                values=(
                    book.book_id,
                    book.isbn,
                    book.title,
                    book.author,
                    book.category,
                    book.publication_year,
                    f"{book.available_copies}/{book.total_copies}",
                    book.shelf_location,
                ),
            )

    def refresh_members(self) -> None:
        self.members_tree.delete(*self.members_tree.get_children())
        for member in self.library_service.search_members(keyword=self.member_search_var.get()):
            loans = self.library_service.get_member_active_loan_count(member.member_id)
            self.members_tree.insert(
                "",
                tk.END,
                values=(
                    member.member_id,
                    member.name,
                    member.membership_type,
                    member.department,
                    member.email,
                    f"{loans}/{member.max_loans}",
                    "Active" if member.active else "Inactive",
                ),
            )

    def refresh_loans(self) -> None:
        self.loans_tree.delete(*self.loans_tree.get_children())
        for txn in self.library_service.search_transactions():
            book = self.library_service.state.books.get(txn.book_id)
            member = self.library_service.state.members.get(txn.member_id)
            self.loans_tree.insert(
                "",
                tk.END,
                iid=txn.record_id,
                values=(
                    txn.record_id,
                    f"{txn.book_id} - {book.title if book else '?'}",
                    f"{txn.member_id} - {member.name if member else '?'}",
                    txn.issue_date,
                    txn.due_date,
                    txn.return_date or "-",
                    txn.effective_status(),
                    f"{txn.fine_amount:.2f}",
                ),
            )

    def refresh_analytics(self) -> None:
        summary = self.analytics_service.generate_executive_summary()
        lines = [
            f"EXECUTIVE SUMMARY ({summary.generated_date}) | STATUS: {summary.health_status}",
            "=" * 72,
            f"Catalog Titles        : {summary.total_titles}",
            f"Copies (Avail / Tot)  : {summary.available_copies} / {summary.total_copies} ({summary.utilization_rate_pct:.2f}% utilized)",
            f"Members (Active / Tot): {summary.active_members} / {summary.total_members}",
            f"Active / Overdue Loans: {summary.active_loans} / {summary.overdue_loans}",
            f"Return / On-Time Rate : {summary.return_rate_pct:.2f}% / {summary.on_time_return_rate_pct:.2f}%",
            f"Fines (Collected/Pend): {summary.total_fines_collected:.2f} / {summary.pending_estimated_fines:.2f}",
            "",
            "THRESHOLD WARNING INDICATORS:",
            "-" * 72,
        ]
        if summary.warnings:
            for warn in summary.warnings:
                lines.append(f"[{warn.severity}] ({warn.category}) {warn.message}")
        else:
            lines.append("No active warnings or integrity anomalies.")

        self.summary_text.configure(state=tk.NORMAL)
        self.summary_text.delete("1.0", tk.END)
        self.summary_text.insert("1.0", "\n".join(lines))
        self.summary_text.configure(state=tk.DISABLED)

    def _dialog_add_book(self) -> None:
        isbn = simpledialog.askstring("Add Book", "ISBN (10 or 13 digits):", parent=self.root)
        if isbn is None:
            return
        title = simpledialog.askstring("Add Book", "Title:", parent=self.root)
        author = simpledialog.askstring("Add Book", "Author:", parent=self.root)
        category = simpledialog.askstring("Add Book", "Category:", parent=self.root)
        year = simpledialog.askstring("Add Book", "Publication Year:", parent=self.root)
        copies = simpledialog.askstring("Add Book", "Total Copies:", parent=self.root)
        if None in (title, author, category, year, copies):
            return
        try:
            book = self.library_service.add_book(isbn, title, author, category, year, copies)
            self.refresh_all()
            messagebox.showinfo("Book Added", f"Added {book.book_id}: {book.title}", parent=self.root)
        except LibraryAppError as exc:
            messagebox.showerror("Validation Error", str(exc), parent=self.root)

    def _dialog_add_member(self) -> None:
        name = simpledialog.askstring("Register Member", "Full Name:", parent=self.root)
        if name is None:
            return
        email = simpledialog.askstring("Register Member", "Email:", parent=self.root)
        phone = simpledialog.askstring("Register Member", "Phone (10-15 digits):", parent=self.root)
        dept = simpledialog.askstring("Register Member", "Department:", parent=self.root)
        tier = simpledialog.askstring("Register Member", "Tier (Student/Faculty/Staff/Researcher):", initialvalue="Student", parent=self.root)
        if None in (email, phone, dept, tier):
            return
        try:
            member = self.library_service.register_member(name, email, phone, dept, tier)
            self.refresh_all()
            messagebox.showinfo("Member Registered", f"Registered {member.member_id}: {member.name}", parent=self.root)
        except LibraryAppError as exc:
            messagebox.showerror("Validation Error", str(exc), parent=self.root)

    def _dialog_issue_book(self) -> None:
        member_id = simpledialog.askstring("Issue Book", "Member ID (e.g., MEM-002):", parent=self.root)
        if member_id is None:
            return
        book_id = simpledialog.askstring("Issue Book", "Book ID (e.g., BK-001):", parent=self.root)
        if book_id is None:
            return
        try:
            txn = self.library_service.issue_book(member_id, book_id)
            self.refresh_all()
            messagebox.showinfo("Book Issued", f"Created {txn.record_id}. Due: {txn.due_date}", parent=self.root)
        except LibraryAppError as exc:
            messagebox.showerror("Business Rule Error", str(exc), parent=self.root)

    def _action_return_selected(self) -> None:
        selected = self.loans_tree.selection()
        if not selected:
            messagebox.showwarning("Selection Required", "Select a loan row to return.", parent=self.root)
            return
        try:
            txn = self.library_service.return_book(selected[0])
            self.refresh_all()
            messagebox.showinfo("Returned", f"Returned {txn.record_id}. Fine: {txn.fine_amount:.2f}", parent=self.root)
        except LibraryAppError as exc:
            messagebox.showerror("Error", str(exc), parent=self.root)

    def _action_renew_selected(self) -> None:
        selected = self.loans_tree.selection()
        if not selected:
            messagebox.showwarning("Selection Required", "Select an active loan row to renew.", parent=self.root)
            return
        try:
            txn = self.library_service.renew_loan(selected[0])
            self.refresh_all()
            messagebox.showinfo("Renewed", f"Extended {txn.record_id} to {txn.due_date}.", parent=self.root)
        except LibraryAppError as exc:
            messagebox.showerror("Error", str(exc), parent=self.root)

    def _action_bulk_import_books(self) -> None:
        path = filedialog.askopenfilename(
            title="Select Legacy Books CSV",
            filetypes=[("CSV files", "*.csv")],
            parent=self.root,
        )
        if not path:
            return
        try:
            res = self.import_export_service.bulk_import_books(path)
            self.refresh_all()
            msg = f"Imported {res.imported_count}/{res.total_rows} rows. Skipped: {res.skipped_count}."
            if res.error_log_path:
                msg += f"\nError log: {res.error_log_path}"
            messagebox.showinfo("Bulk Import Result", msg, parent=self.root)
        except LibraryAppError as exc:
            messagebox.showerror("Import Error", str(exc), parent=self.root)

    def _export_md(self) -> None:
        out = self.import_export_service.export_markdown_summary()
        messagebox.showinfo("Export Complete", f"Markdown report saved:\n{out}", parent=self.root)

    def _export_csv(self) -> None:
        out = self.import_export_service.export_csv_summary()
        messagebox.showinfo("Export Complete", f"CSV summary saved:\n{out}", parent=self.root)

    def _export_audit(self) -> None:
        out = self.import_export_service.export_audit_log_report()
        messagebox.showinfo("Export Complete", f"Audit log saved:\n{out}", parent=self.root)


def launch_gui(
    library_service: LibraryService,
    analytics_service: AnalyticsService,
    import_export_service: ImportExportService,
) -> None:
    """Create and run the optional Tkinter GUI event loop."""
    root = tk.Tk()
    LibraryGUI(root, library_service, analytics_service, import_export_service)
    root.mainloop()
