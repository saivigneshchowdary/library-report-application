"""Member domain model."""

from dataclasses import asdict, dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class MembershipType(str, Enum):
    """Supported campus library membership tiers."""

    STUDENT = "Student"
    FACULTY = "Faculty"
    STAFF = "Staff"
    RESEARCHER = "Researcher"


@dataclass
class Member:
    """Represents a registered library borrower."""

    member_id: str
    name: str
    email: str
    phone: str
    department: str
    membership_type: str = MembershipType.STUDENT.value
    max_loans: int = 5
    joined_at: str = ""
    active: bool = True

    def __post_init__(self) -> None:
        if not self.joined_at:
            self.joined_at = datetime.now().strftime("%Y-%m-%d")

    def to_dict(self) -> dict[str, Any]:
        """Serialize the member into a JSON/CSV-friendly dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Member":
        """Reconstruct a Member instance from a dictionary with type coercion."""
        active_val = raw.get("active", True)
        if isinstance(active_val, str):
            active_bool = active_val.strip().lower() in {"true", "1", "yes"}
        else:
            active_bool = bool(active_val)

        return cls(
            member_id=str(raw["member_id"]).strip(),
            name=str(raw["name"]).strip(),
            email=str(raw["email"]).strip(),
            phone=str(raw["phone"]).strip(),
            department=str(raw["department"]).strip(),
            membership_type=str(raw.get("membership_type", MembershipType.STUDENT.value)).strip(),
            max_loans=int(raw.get("max_loans", 5)),
            joined_at=str(raw.get("joined_at", "")).strip(),
            active=active_bool,
        )
