"""Book domain model."""

from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any


@dataclass
class Book:
    """Represents a cataloged book title and its copy inventory."""

    book_id: str
    isbn: str
    title: str
    author: str
    category: str
    publication_year: int
    total_copies: int
    available_copies: int
    shelf_location: str = "GEN-A1"
    added_at: str = ""

    def __post_init__(self) -> None:
        if not self.added_at:
            self.added_at = datetime.now().strftime("%Y-%m-%d")

    @property
    def issued_copies(self) -> int:
        """Return the number of copies currently checked out."""
        return max(0, self.total_copies - self.available_copies)

    @property
    def is_available(self) -> bool:
        """Return True if at least one copy can be issued."""
        return self.available_copies > 0

    def to_dict(self) -> dict[str, Any]:
        """Serialize the book into a JSON/CSV-friendly dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "Book":
        """Reconstruct a Book instance from a dictionary with type coercion."""
        return cls(
            book_id=str(raw["book_id"]).strip(),
            isbn=str(raw["isbn"]).strip(),
            title=str(raw["title"]).strip(),
            author=str(raw["author"]).strip(),
            category=str(raw["category"]).strip(),
            publication_year=int(raw["publication_year"]),
            total_copies=int(raw["total_copies"]),
            available_copies=int(raw["available_copies"]),
            shelf_location=str(raw.get("shelf_location", "GEN-A1")).strip() or "GEN-A1",
            added_at=str(raw.get("added_at", "")).strip(),
        )
