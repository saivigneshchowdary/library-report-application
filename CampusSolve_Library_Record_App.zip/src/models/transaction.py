"""Loan transaction domain model for book issues and returns."""

from dataclasses import asdict, dataclass
from datetime import date
from enum import Enum
from typing import Any


class LoanStatus(str, Enum):
    """Lifecycle status of a book loan transaction."""

    ISSUED = "ISSUED"
    RETURNED = "RETURNED"


@dataclass
class LoanTransaction:
    """Represents an issue/return record linking a member and a book."""

    record_id: str
    book_id: str
    member_id: str
    issue_date: str
    due_date: str
    return_date: str | None = None
    status: str = LoanStatus.ISSUED.value
    fine_amount: float = 0.0
    renewal_count: int = 0
    notes: str = ""

    def is_overdue(self, reference_date: date | None = None) -> bool:
        """Return True when an unreturned loan is past its due date."""
        if self.status == LoanStatus.RETURNED.value:
            return False
        today = reference_date or date.today()
        return today > date.fromisoformat(self.due_date)

    def overdue_days(self, reference_date: date | None = None) -> int:
        """Calculate the number of days past the due date."""
        due = date.fromisoformat(self.due_date)
        if self.status == LoanStatus.RETURNED.value and self.return_date:
            end_date = date.fromisoformat(self.return_date)
        else:
            end_date = reference_date or date.today()
        return max(0, (end_date - due).days)

    def effective_status(self, reference_date: date | None = None) -> str:
        """Return 'OVERDUE' dynamically if unreturned and past due date."""
        if self.status == LoanStatus.RETURNED.value:
            return LoanStatus.RETURNED.value
        return "OVERDUE" if self.is_overdue(reference_date) else LoanStatus.ISSUED.value

    def to_dict(self) -> dict[str, Any]:
        """Serialize the transaction into a JSON/CSV-friendly dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "LoanTransaction":
        """Reconstruct a LoanTransaction from a dictionary with safe parsing."""
        ret_date = raw.get("return_date")
        if ret_date is not None:
            ret_str = str(ret_date).strip()
            ret_date = ret_str if ret_str else None

        return cls(
            record_id=str(raw["record_id"]).strip(),
            book_id=str(raw["book_id"]).strip(),
            member_id=str(raw["member_id"]).strip(),
            issue_date=str(raw["issue_date"]).strip(),
            due_date=str(raw["due_date"]).strip(),
            return_date=ret_date,
            status=str(raw.get("status", LoanStatus.ISSUED.value)).strip().upper(),
            fine_amount=float(raw.get("fine_amount", 0.0) or 0.0),
            renewal_count=int(raw.get("renewal_count", 0) or 0),
            notes=str(raw.get("notes", "")).strip(),
        )
