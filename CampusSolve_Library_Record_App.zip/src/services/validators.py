"""Defensive input sanitization and domain constraint validators."""

from datetime import date
from pathlib import Path
import re

from src.config import DEFAULT_CONFIG
from src.exceptions import ValidationError
from src.models import MembershipType


_CONTROL_CHAR_PATTERN = re.compile(r"[\x00-\x1f\x7f]")
_EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
_SHELF_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-]{1,19}$")


def sanitize_text(
    value: str,
    field_name: str,
    min_length: int = 1,
    max_length: int = 120,
    allow_empty: bool = False,
) -> str:
    """Strip whitespace and control characters, then enforce length bounds."""
    if not isinstance(value, str):
        raise ValidationError(f"{field_name} must be a text string.")
    cleaned = _CONTROL_CHAR_PATTERN.sub("", value).strip()
    if not cleaned:
        if allow_empty:
            return ""
        raise ValidationError(f"{field_name} cannot be blank.")
    if len(cleaned) < min_length:
        raise ValidationError(f"{field_name} must be at least {min_length} characters.")
    if len(cleaned) > max_length:
        raise ValidationError(f"{field_name} cannot exceed {max_length} characters.")
    return cleaned


def validate_isbn(raw_isbn: str) -> str:
    """Validate an ISBN-10 or ISBN-13 checksum and return its canonical digits."""
    cleaned = sanitize_text(raw_isbn, "ISBN", min_length=10, max_length=25)
    compact = re.sub(r"[-\s]", "", cleaned).upper()

    if len(compact) == 10:
        if not re.match(r"^\d{9}[\dX]$", compact):
            raise ValidationError("ISBN-10 must contain 9 digits followed by a digit or 'X'.")
        total = sum(
            (10 - idx) * (10 if char == "X" else int(char))
            for idx, char in enumerate(compact)
        )
        if total % 11 != 0:
            raise ValidationError(f"Invalid ISBN-10 checksum: '{raw_isbn}'.")
        return compact

    if len(compact) == 13:
        if not compact.isdigit():
            raise ValidationError("ISBN-13 must contain exactly 13 numeric digits.")
        total = sum(
            int(char) * (1 if idx % 2 == 0 else 3)
            for idx, char in enumerate(compact[:12])
        )
        check_digit = (10 - (total % 10)) % 10
        if check_digit != int(compact[12]):
            raise ValidationError(f"Invalid ISBN-13 checksum: '{raw_isbn}'.")
        return compact

    raise ValidationError("ISBN must be either 10 or 13 digits (hyphens allowed).")


def validate_positive_int(
    raw_value: str | int,
    field_name: str,
    min_value: int = 1,
    max_value: int = 10000,
) -> int:
    """Parse an integer and verify it lies within [min_value, max_value]."""
    try:
        if isinstance(raw_value, bool):
            raise ValueError("Boolean is not a valid integer.")
        parsed = int(str(raw_value).strip())
    except ValueError as exc:
        raise ValidationError(f"{field_name} must be a whole number.") from exc

    if parsed < min_value or parsed > max_value:
        raise ValidationError(
            f"{field_name} must be between {min_value} and {max_value}."
        )
    return parsed


def validate_publication_year(raw_year: str | int) -> int:
    """Validate that a book's publication year is within realistic historical bounds."""
    return validate_positive_int(
        raw_year,
        "Publication Year",
        min_value=DEFAULT_CONFIG.min_publication_year,
        max_value=DEFAULT_CONFIG.max_publication_year,
    )


def validate_email(raw_email: str) -> str:
    """Validate email format after sanitization."""
    cleaned = sanitize_text(raw_email, "Email", min_length=5, max_length=120).lower()
    if not _EMAIL_PATTERN.match(cleaned):
        raise ValidationError(f"Invalid email format: '{raw_email}'.")
    return cleaned


def validate_phone(raw_phone: str) -> str:
    """Validate phone number containing 10 to 15 digits."""
    cleaned = sanitize_text(raw_phone, "Phone", min_length=10, max_length=25)
    digits = re.sub(r"[\s\-\+\(\)]", "", cleaned)
    if not digits.isdigit() or not (10 <= len(digits) <= 15):
        raise ValidationError("Phone number must contain 10 to 15 digits.")
    return cleaned


def validate_shelf_location(raw_shelf: str) -> str:
    """Validate shelf code such as 'CS-A1' or 'GEN-B2'."""
    cleaned = sanitize_text(raw_shelf, "Shelf Location", min_length=2, max_length=20).upper()
    if not _SHELF_PATTERN.match(cleaned):
        raise ValidationError(
            "Shelf Location must be 2-20 alphanumeric characters or hyphens (e.g., CS-A1)."
        )
    return cleaned


def validate_membership_type(raw_type: str) -> str:
    """Validate membership tier against supported MembershipType enum values."""
    cleaned = sanitize_text(raw_type, "Membership Type", min_length=3, max_length=30)
    mapping = {tier.value.lower(): tier.value for tier in MembershipType}
    normalized = mapping.get(cleaned.lower())
    if not normalized:
        valid = ", ".join(tier.value for tier in MembershipType)
        raise ValidationError(f"Membership Type must be one of: {valid}.")
    return normalized


def validate_iso_date(raw_date: str, field_name: str = "Date") -> date:
    """Parse and validate an ISO-8601 date string (YYYY-MM-DD)."""
    cleaned = sanitize_text(raw_date, field_name, min_length=10, max_length=10)
    try:
        return date.fromisoformat(cleaned)
    except ValueError as exc:
        raise ValidationError(f"{field_name} must use YYYY-MM-DD format.") from exc


def validate_safe_export_filename(raw_filename: str, expected_extension: str) -> str:
    """Ensure export filenames contain no path traversal or illegal characters."""
    cleaned = sanitize_text(raw_filename, "Filename", min_length=1, max_length=80)
    candidate = Path(cleaned).name
    if candidate != cleaned or ".." in cleaned or "/" in cleaned or "\\" in cleaned:
        raise ValidationError("Filename must be a plain file name without directory paths.")
    safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", candidate)
    if not safe_name.lower().endswith(expected_extension.lower()):
        safe_name += expected_extension
    return safe_name
