"""Executive summary aggregation and trend analysis service."""

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date

from src.config import DEFAULT_CONFIG, LibraryConfig
from src.models import LoanStatus
from src.services.library_service import LibraryService, ThresholdWarning


@dataclass(frozen=True)
class CategoryStats:
    """Aggregated inventory and circulation metrics for one book category."""

    category: str
    title_count: int
    total_copies: int
    available_copies: int
    issued_copies: int
    historical_loans: int


@dataclass(frozen=True)
class ExecutiveSummary:
    """Comprehensive snapshot of library KPIs, rankings, trends, and alerts."""

    generated_date: str
    health_status: str
    total_titles: int
    total_copies: int
    available_copies: int
    issued_copies: int
    utilization_rate_pct: float
    total_members: int
    active_members: int
    inactive_members: int
    avg_loans_per_active_member: float
    total_transactions: int
    active_loans: int
    returned_loans: int
    overdue_loans: int
    return_rate_pct: float
    on_time_return_rate_pct: float
    avg_overdue_days: float
    total_fines_collected: float
    pending_estimated_fines: float
    category_breakdown: list[CategoryStats]
    membership_breakdown: dict[str, int]
    top_borrowed_books: list[tuple[str, str, int]]
    top_borrowers: list[tuple[str, str, int]]
    monthly_issue_trend: list[tuple[str, int]]
    warnings: list[ThresholdWarning]


class AnalyticsService:
    """Computes executive metrics, averages, trends, and status indicators."""

    def __init__(
        self,
        library_service: LibraryService,
        config: LibraryConfig = DEFAULT_CONFIG,
    ) -> None:
        self.library_service = library_service
        self.config = config

    def generate_executive_summary(self, reference_date: date | None = None) -> ExecutiveSummary:
        """Aggregate all library collections into an ExecutiveSummary snapshot."""
        today = reference_date or date.today()
        state = self.library_service.state

        books = list(state.books.values())
        members = list(state.members.values())
        transactions = list(state.transactions.values())

        total_titles = len(books)
        total_copies = sum(book.total_copies for book in books)
        available_copies = sum(book.available_copies for book in books)
        issued_copies = sum(book.issued_copies for book in books)
        utilization_rate = round((issued_copies / total_copies) * 100, 2) if total_copies else 0.0

        total_members = len(members)
        active_members = sum(1 for member in members if member.active)
        inactive_members = total_members - active_members

        active_txns = [txn for txn in transactions if txn.status == LoanStatus.ISSUED.value]
        returned_txns = [txn for txn in transactions if txn.status == LoanStatus.RETURNED.value]
        overdue_txns = [txn for txn in active_txns if txn.is_overdue(today)]

        avg_loans_per_active_member = (
            round(len(active_txns) / active_members, 2) if active_members else 0.0
        )

        total_txns = len(transactions)
        return_rate = round((len(returned_txns) / total_txns) * 100, 2) if total_txns else 0.0

        on_time_returns = sum(1 for txn in returned_txns if txn.overdue_days(today) == 0)
        on_time_rate = (
            round((on_time_returns / len(returned_txns)) * 100, 2) if returned_txns else 100.0
        )

        overdue_day_samples = [
            txn.overdue_days(today)
            for txn in transactions
            if txn.overdue_days(today) > 0
        ]
        avg_overdue_days = (
            round(sum(overdue_day_samples) / len(overdue_day_samples), 2)
            if overdue_day_samples
            else 0.0
        )

        total_fines_collected = round(sum(txn.fine_amount for txn in returned_txns), 2)
        pending_estimated_fines = round(
            sum(txn.overdue_days(today) * self.config.daily_fine_rate for txn in overdue_txns),
            2,
        )

        # Category aggregation
        loan_count_by_book: Counter[str] = Counter(txn.book_id for txn in transactions)
        cat_groups: dict[str, list] = defaultdict(list)
        for book in books:
            cat_groups[book.category].append(book)

        category_breakdown: list[CategoryStats] = []
        for category_name in sorted(cat_groups.keys()):
            cat_books = cat_groups[category_name]
            category_breakdown.append(
                CategoryStats(
                    category=category_name,
                    title_count=len(cat_books),
                    total_copies=sum(b.total_copies for b in cat_books),
                    available_copies=sum(b.available_copies for b in cat_books),
                    issued_copies=sum(b.issued_copies for b in cat_books),
                    historical_loans=sum(loan_count_by_book[b.book_id] for b in cat_books),
                )
            )

        membership_breakdown = dict(
            sorted(Counter(member.membership_type for member in members).items())
        )

        # Top 5 borrowed books
        top_borrowed_books: list[tuple[str, str, int]] = []
        for book_id, count in loan_count_by_book.most_common(5):
            book = state.books.get(book_id)
            title = book.title if book else "Unknown Book"
            top_borrowed_books.append((book_id, title, count))

        # Top 5 borrowers
        loan_count_by_member: Counter[str] = Counter(txn.member_id for txn in transactions)
        top_borrowers: list[tuple[str, str, int]] = []
        for member_id, count in loan_count_by_member.most_common(5):
            member = state.members.get(member_id)
            name = member.name if member else "Unknown Member"
            top_borrowers.append((member_id, name, count))

        # Monthly issue trend (YYYY-MM)
        month_counter: Counter[str] = Counter(txn.issue_date[:7] for txn in transactions if len(txn.issue_date) >= 7)
        monthly_issue_trend = sorted(month_counter.items())

        warnings = self.library_service.get_threshold_warnings(today)
        if any(w.severity in {"CRITICAL", "ANOMALY"} for w in warnings):
            health_status = "CRITICAL"
        elif warnings:
            health_status = "ATTENTION_NEEDED"
        else:
            health_status = "HEALTHY"

        return ExecutiveSummary(
            generated_date=today.isoformat(),
            health_status=health_status,
            total_titles=total_titles,
            total_copies=total_copies,
            available_copies=available_copies,
            issued_copies=issued_copies,
            utilization_rate_pct=utilization_rate,
            total_members=total_members,
            active_members=active_members,
            inactive_members=inactive_members,
            avg_loans_per_active_member=avg_loans_per_active_member,
            total_transactions=total_txns,
            active_loans=len(active_txns),
            returned_loans=len(returned_txns),
            overdue_loans=len(overdue_txns),
            return_rate_pct=return_rate,
            on_time_return_rate_pct=on_time_rate,
            avg_overdue_days=avg_overdue_days,
            total_fines_collected=total_fines_collected,
            pending_estimated_fines=pending_estimated_fines,
            category_breakdown=category_breakdown,
            membership_breakdown=membership_breakdown,
            top_borrowed_books=top_borrowed_books,
            top_borrowers=top_borrowers,
            monthly_issue_trend=monthly_issue_trend,
            warnings=warnings,
        )
