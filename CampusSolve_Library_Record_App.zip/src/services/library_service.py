"""Core business logic engine for books, members, loans, searches, and warnings."""

from dataclasses import dataclass
from datetime import date, timedelta

from src.config import DEFAULT_CONFIG, LibraryConfig
from src.exceptions import (
    BusinessRuleError,
    DuplicateRecordError,
    NotFoundError,
    ValidationError,
)
from src.models import Book, LoanStatus, LoanTransaction, Member
from src.repositories import AuditLogger, LibraryRepository, LibraryState
from src.services.validators import (
    sanitize_text,
    validate_email,
    validate_isbn,
    validate_membership_type,
    validate_phone,
    validate_positive_int,
    validate_publication_year,
    validate_shelf_location,
)


@dataclass(frozen=True)
class ThresholdWarning:
    """Represents an automated warning or anomaly detected in library state."""

    severity: str  # CRITICAL | WARNING | ANOMALY
    category: str  # OVERDUE | DUE_SOON | STOCK | LOAN_LIMIT | INTEGRITY
    entity_id: str
    message: str


class LibraryService:
    """Coordinates domain rules, state mutations, persistence, and audit logging."""

    def __init__(
        self,
        repository: LibraryRepository,
        audit_logger: AuditLogger,
        config: LibraryConfig = DEFAULT_CONFIG,
    ) -> None:
        self.repository = repository
        self.audit_logger = audit_logger
        self.config = config
        self.state: LibraryState = self.repository.load_state()

    def reload(self) -> list[str]:
        """Reload state from disk and return any recovery warnings."""
        self.state = self.repository.load_state()
        return list(self.state.recovery_warnings)

    def _persist(self) -> None:
        """Persist current in-memory state to JSON and CSV files."""
        self.repository.save_state(self.state)

    # ------------------------------------------------------------------
    # ID Generation
    # ------------------------------------------------------------------
    def _next_id(self, prefix: str, existing_ids: set[str]) -> str:
        """Generate the next sequential formatted ID (e.g., BK-001)."""
        highest = 0
        for item_id in existing_ids:
            if item_id.startswith(prefix):
                suffix = item_id[len(prefix):]
                if suffix.isdigit():
                    highest = max(highest, int(suffix))
        return f"{prefix}{highest + 1:03d}"

    # ------------------------------------------------------------------
    # Book Management
    # ------------------------------------------------------------------
    def add_book(
        self,
        isbn: str,
        title: str,
        author: str,
        category: str,
        publication_year: int | str,
        total_copies: int | str,
        shelf_location: str = "GEN-A1",
        book_id: str | None = None,
    ) -> Book:
        """Validate and add a new book to the catalog."""
        clean_isbn = validate_isbn(isbn)
        clean_title = sanitize_text(title, "Title", min_length=1, max_length=140)
        clean_author = sanitize_text(author, "Author", min_length=2, max_length=100)
        clean_category = sanitize_text(category, "Category", min_length=2, max_length=60)
        clean_year = validate_publication_year(publication_year)
        clean_copies = validate_positive_int(total_copies, "Total Copies", min_value=1, max_value=500)
        clean_shelf = validate_shelf_location(shelf_location)

        if any(existing.isbn == clean_isbn for existing in self.state.books.values()):
            raise DuplicateRecordError(f"A book with ISBN '{clean_isbn}' already exists.")

        assigned_id = (
            sanitize_text(book_id, "Book ID", min_length=2, max_length=20).upper()
            if book_id
            else self._next_id("BK-", set(self.state.books.keys()))
        )
        if assigned_id in self.state.books:
            raise DuplicateRecordError(f"Book ID '{assigned_id}' already exists.")

        book = Book(
            book_id=assigned_id,
            isbn=clean_isbn,
            title=clean_title,
            author=clean_author,
            category=clean_category,
            publication_year=clean_year,
            total_copies=clean_copies,
            available_copies=clean_copies,
            shelf_location=clean_shelf,
        )
        self.state.books[book.book_id] = book
        self._persist()
        self.audit_logger.log(
            "ADD_BOOK",
            "LIBRARIAN",
            f"Added {book.book_id} ('{book.title}', ISBN={book.isbn}, copies={book.total_copies})",
        )
        return book

    def update_book(
        self,
        book_id: str,
        title: str | None = None,
        author: str | None = None,
        category: str | None = None,
        publication_year: int | str | None = None,
        total_copies: int | str | None = None,
        shelf_location: str | None = None,
    ) -> Book:
        """Update mutable fields on an existing book without violating active loans."""
        book = self.get_book(book_id)

        new_title = sanitize_text(title, "Title", max_length=140) if title is not None else book.title
        new_author = sanitize_text(author, "Author", min_length=2, max_length=100) if author is not None else book.author
        new_category = sanitize_text(category, "Category", min_length=2, max_length=60) if category is not None else book.category
        new_year = validate_publication_year(publication_year) if publication_year is not None else book.publication_year
        new_shelf = validate_shelf_location(shelf_location) if shelf_location is not None else book.shelf_location

        new_total = book.total_copies
        new_available = book.available_copies
        if total_copies is not None:
            parsed_total = validate_positive_int(total_copies, "Total Copies", min_value=1, max_value=500)
            currently_issued = book.issued_copies
            if parsed_total < currently_issued:
                raise BusinessRuleError(
                    f"Cannot reduce total copies to {parsed_total}; {currently_issued} copies are currently issued."
                )
            new_total = parsed_total
            new_available = parsed_total - currently_issued

        book.title = new_title
        book.author = new_author
        book.category = new_category
        book.publication_year = new_year
        book.total_copies = new_total
        book.available_copies = new_available
        book.shelf_location = new_shelf

        self._persist()
        self.audit_logger.log("UPDATE_BOOK", "LIBRARIAN", f"Updated {book.book_id} ('{book.title}')")
        return book

    def delete_book(self, book_id: str) -> Book:
        """Remove a book from the catalog if it has no active issued loans."""
        book = self.get_book(book_id)
        active_loans = [
            txn for txn in self.state.transactions.values()
            if txn.book_id == book.book_id and txn.status == LoanStatus.ISSUED.value
        ]
        if active_loans:
            raise BusinessRuleError(
                f"Cannot delete '{book.book_id}'; {len(active_loans)} active loan(s) remain unreturned."
            )
        removed = self.state.books.pop(book.book_id)
        self._persist()
        self.audit_logger.log("DELETE_BOOK", "LIBRARIAN", f"Deleted {removed.book_id} ('{removed.title}')")
        return removed

    def get_book(self, book_id: str) -> Book:
        """Retrieve a book by its ID or raise NotFoundError."""
        key = sanitize_text(book_id, "Book ID", min_length=1, max_length=30).upper()
        if key not in self.state.books:
            raise NotFoundError(f"Book '{key}' was not found.")
        return self.state.books[key]

    def search_books(
        self,
        keyword: str = "",
        category: str = "",
        available_only: bool = False,
    ) -> list[Book]:
        """Filter books by keyword (ID, ISBN, title, author) and category."""
        kw = keyword.strip().lower()
        cat = category.strip().lower()
        results: list[Book] = []

        for book in self.state.books.values():
            if available_only and book.available_copies <= 0:
                continue
            if cat and book.category.lower() != cat:
                continue
            if kw:
                haystack = f"{book.book_id} {book.isbn} {book.title} {book.author} {book.category}".lower()
                if kw not in haystack:
                    continue
            results.append(book)

        return sorted(results, key=lambda item: item.book_id)

    def list_categories(self) -> list[str]:
        """Return sorted distinct book categories."""
        return sorted({book.category for book in self.state.books.values()})

    # ------------------------------------------------------------------
    # Member Management
    # ------------------------------------------------------------------
    def register_member(
        self,
        name: str,
        email: str,
        phone: str,
        department: str,
        membership_type: str = "Student",
        max_loans: int | str | None = None,
        member_id: str | None = None,
    ) -> Member:
        """Validate and register a new library member."""
        clean_name = sanitize_text(name, "Member Name", min_length=2, max_length=100)
        clean_email = validate_email(email)
        clean_phone = validate_phone(phone)
        clean_dept = sanitize_text(department, "Department", min_length=2, max_length=80)
        clean_type = validate_membership_type(membership_type)
        clean_max_loans = (
            validate_positive_int(
                max_loans,
                "Max Loans",
                min_value=1,
                max_value=self.config.max_loans_per_member,
            )
            if max_loans is not None
            else self.config.max_loans_per_member
        )

        if any(existing.email == clean_email for existing in self.state.members.values()):
            raise DuplicateRecordError(f"A member with email '{clean_email}' is already registered.")

        assigned_id = (
            sanitize_text(member_id, "Member ID", min_length=2, max_length=20).upper()
            if member_id
            else self._next_id("MEM-", set(self.state.members.keys()))
        )
        if assigned_id in self.state.members:
            raise DuplicateRecordError(f"Member ID '{assigned_id}' already exists.")

        member = Member(
            member_id=assigned_id,
            name=clean_name,
            email=clean_email,
            phone=clean_phone,
            department=clean_dept,
            membership_type=clean_type,
            max_loans=clean_max_loans,
            active=True,
        )
        self.state.members[member.member_id] = member
        self._persist()
        self.audit_logger.log(
            "REGISTER_MEMBER",
            "LIBRARIAN",
            f"Registered {member.member_id} ({member.name}, {member.membership_type})",
        )
        return member

    def update_member(
        self,
        member_id: str,
        name: str | None = None,
        phone: str | None = None,
        department: str | None = None,
        membership_type: str | None = None,
        active: bool | None = None,
    ) -> Member:
        """Update member profile or active status."""
        member = self.get_member(member_id)
        if name is not None:
            member.name = sanitize_text(name, "Member Name", min_length=2, max_length=100)
        if phone is not None:
            member.phone = validate_phone(phone)
        if department is not None:
            member.department = sanitize_text(department, "Department", min_length=2, max_length=80)
        if membership_type is not None:
            member.membership_type = validate_membership_type(membership_type)
        if active is not None:
            if not active and self.get_member_active_loan_count(member.member_id) > 0:
                raise BusinessRuleError(
                    f"Cannot deactivate '{member.member_id}' while they hold unreturned books."
                )
            member.active = active

        self._persist()
        self.audit_logger.log("UPDATE_MEMBER", "LIBRARIAN", f"Updated {member.member_id} ({member.name})")
        return member

    def get_member(self, member_id: str) -> Member:
        """Retrieve a member by ID or raise NotFoundError."""
        key = sanitize_text(member_id, "Member ID", min_length=1, max_length=30).upper()
        if key not in self.state.members:
            raise NotFoundError(f"Member '{key}' was not found.")
        return self.state.members[key]

    def get_member_active_loan_count(self, member_id: str) -> int:
        """Return count of currently unreturned books held by a member."""
        return sum(
            1
            for txn in self.state.transactions.values()
            if txn.member_id == member_id and txn.status == LoanStatus.ISSUED.value
        )

    def search_members(
        self,
        keyword: str = "",
        membership_type: str = "",
        active_only: bool = False,
    ) -> list[Member]:
        """Filter members by keyword, membership tier, and active flag."""
        kw = keyword.strip().lower()
        tier = membership_type.strip().lower()
        results: list[Member] = []

        for member in self.state.members.values():
            if active_only and not member.active:
                continue
            if tier and member.membership_type.lower() != tier:
                continue
            if kw:
                haystack = (
                    f"{member.member_id} {member.name} {member.email} "
                    f"{member.department} {member.membership_type}"
                ).lower()
                if kw not in haystack:
                    continue
            results.append(member)

        return sorted(results, key=lambda item: item.member_id)

    # ------------------------------------------------------------------
    # Issue, Return & Renewal Engine
    # ------------------------------------------------------------------
    def issue_book(
        self,
        member_id: str,
        book_id: str,
        loan_days: int | str | None = None,
        issue_date: date | None = None,
        notes: str = "",
    ) -> LoanTransaction:
        """Issue one copy of a book to an eligible active member."""
        member = self.get_member(member_id)
        book = self.get_book(book_id)

        if not member.active:
            raise BusinessRuleError(f"Member '{member.member_id}' ({member.name}) is inactive.")
        if book.available_copies <= 0:
            raise BusinessRuleError(
                f"Book '{book.book_id}' ('{book.title}') has 0 copies available."
            )

        active_loans = [
            txn for txn in self.state.transactions.values()
            if txn.member_id == member.member_id and txn.status == LoanStatus.ISSUED.value
        ]
        if len(active_loans) >= member.max_loans:
            raise BusinessRuleError(
                f"Member '{member.member_id}' has reached the maximum loan limit ({member.max_loans})."
            )
        if any(txn.book_id == book.book_id for txn in active_loans):
            raise BusinessRuleError(
                f"Member '{member.member_id}' already holds an active loan for '{book.book_id}'."
            )

        days = (
            validate_positive_int(loan_days, "Loan Duration (days)", min_value=1, max_value=60)
            if loan_days is not None
            else self.config.default_loan_days
        )
        start_date = issue_date or date.today()
        due_date = start_date + timedelta(days=days)
        clean_notes = sanitize_text(notes, "Notes", min_length=0, max_length=200, allow_empty=True)

        record_id = self._next_id("TXN-", set(self.state.transactions.keys()))
        txn = LoanTransaction(
            record_id=record_id,
            book_id=book.book_id,
            member_id=member.member_id,
            issue_date=start_date.isoformat(),
            due_date=due_date.isoformat(),
            status=LoanStatus.ISSUED.value,
            fine_amount=0.0,
            renewal_count=0,
            notes=clean_notes,
        )

        book.available_copies -= 1
        self.state.transactions[txn.record_id] = txn
        self._persist()
        self.audit_logger.log(
            "ISSUE_BOOK",
            "LIBRARIAN",
            f"{txn.record_id}: Issued {book.book_id} to {member.member_id} (due {txn.due_date})",
        )
        return txn

    def return_book(
        self,
        record_id: str,
        return_date: date | None = None,
        notes: str = "",
    ) -> LoanTransaction:
        """Process a book return, restore copy inventory, and calculate overdue fines."""
        txn = self.get_transaction(record_id)
        if txn.status == LoanStatus.RETURNED.value:
            raise BusinessRuleError(f"Transaction '{txn.record_id}' was already returned on {txn.return_date}.")

        actual_return = return_date or date.today()
        issued_on = date.fromisoformat(txn.issue_date)
        if actual_return < issued_on:
            raise ValidationError(
                f"Return date ({actual_return.isoformat()}) cannot be earlier than issue date ({txn.issue_date})."
            )

        overdue = max(0, (actual_return - date.fromisoformat(txn.due_date)).days)
        fine = round(overdue * self.config.daily_fine_rate, 2)

        book = self.state.books.get(txn.book_id)
        if book is not None:
            book.available_copies = min(book.total_copies, book.available_copies + 1)

        txn.return_date = actual_return.isoformat()
        txn.status = LoanStatus.RETURNED.value
        txn.fine_amount = fine
        if notes.strip():
            clean_notes = sanitize_text(notes, "Notes", min_length=1, max_length=200)
            txn.notes = f"{txn.notes}; {clean_notes}".strip("; ")

        self._persist()
        self.audit_logger.log(
            "RETURN_BOOK",
            "LIBRARIAN",
            f"{txn.record_id}: Returned {txn.book_id} by {txn.member_id} "
            f"(overdue_days={overdue}, fine={fine:.2f})",
        )
        return txn

    def renew_loan(self, record_id: str, extra_days: int | str | None = None) -> LoanTransaction:
        """Extend the due date of an active, non-overdue loan (up to 2 renewals)."""
        txn = self.get_transaction(record_id)
        if txn.status == LoanStatus.RETURNED.value:
            raise BusinessRuleError(f"Cannot renew '{txn.record_id}' because it is already returned.")
        if txn.is_overdue():
            raise BusinessRuleError(
                f"Cannot renew '{txn.record_id}' because it is already overdue. Please return and settle fines."
            )
        if txn.renewal_count >= 2:
            raise BusinessRuleError(f"Transaction '{txn.record_id}' has reached the maximum of 2 renewals.")

        days = (
            validate_positive_int(
                extra_days,
                "Extension Days",
                min_value=1,
                max_value=self.config.max_renewal_days,
            )
            if extra_days is not None
            else self.config.max_renewal_days
        )
        new_due = date.fromisoformat(txn.due_date) + timedelta(days=days)
        txn.due_date = new_due.isoformat()
        txn.renewal_count += 1
        self._persist()
        self.audit_logger.log(
            "RENEW_LOAN",
            "LIBRARIAN",
            f"{txn.record_id}: Extended due date to {txn.due_date} (renewal #{txn.renewal_count})",
        )
        return txn

    def get_transaction(self, record_id: str) -> LoanTransaction:
        """Retrieve a transaction by ID or raise NotFoundError."""
        key = sanitize_text(record_id, "Transaction ID", min_length=1, max_length=30).upper()
        if key not in self.state.transactions:
            raise NotFoundError(f"Transaction '{key}' was not found.")
        return self.state.transactions[key]

    def search_transactions(
        self,
        keyword: str = "",
        status_filter: str = "",
        reference_date: date | None = None,
    ) -> list[LoanTransaction]:
        """Filter loan transactions by keyword and effective status (ISSUED/RETURNED/OVERDUE)."""
        kw = keyword.strip().lower()
        status_norm = status_filter.strip().upper()
        results: list[LoanTransaction] = []

        for txn in self.state.transactions.values():
            eff_status = txn.effective_status(reference_date)
            if status_norm and eff_status != status_norm:
                continue
            if kw:
                book = self.state.books.get(txn.book_id)
                member = self.state.members.get(txn.member_id)
                book_title = book.title if book else ""
                member_name = member.name if member else ""
                haystack = (
                    f"{txn.record_id} {txn.book_id} {txn.member_id} "
                    f"{book_title} {member_name} {eff_status}"
                ).lower()
                if kw not in haystack:
                    continue
            results.append(txn)

        return sorted(results, key=lambda item: item.record_id, reverse=True)

    # ------------------------------------------------------------------
    # Stretch Feature: Threshold Warning Indicators
    # ------------------------------------------------------------------
    def get_threshold_warnings(self, reference_date: date | None = None) -> list[ThresholdWarning]:
        """Detect overdue deadlines, stock depletion, loan caps, and data anomalies."""
        today = reference_date or date.today()
        warnings: list[ThresholdWarning] = []

        # 1. Overdue and due-soon loans + orphan integrity checks
        for txn in sorted(self.state.transactions.values(), key=lambda t: t.record_id):
            if txn.book_id not in self.state.books:
                warnings.append(
                    ThresholdWarning(
                        severity="ANOMALY",
                        category="INTEGRITY",
                        entity_id=txn.record_id,
                        message=f"Transaction {txn.record_id} references missing book '{txn.book_id}'.",
                    )
                )
            if txn.member_id not in self.state.members:
                warnings.append(
                    ThresholdWarning(
                        severity="ANOMALY",
                        category="INTEGRITY",
                        entity_id=txn.record_id,
                        message=f"Transaction {txn.record_id} references missing member '{txn.member_id}'.",
                    )
                )

            if txn.status == LoanStatus.ISSUED.value:
                due = date.fromisoformat(txn.due_date)
                delta = (today - due).days
                book_title = self.state.books[txn.book_id].title if txn.book_id in self.state.books else txn.book_id
                member_name = self.state.members[txn.member_id].name if txn.member_id in self.state.members else txn.member_id

                if delta > 7:
                    est_fine = delta * self.config.daily_fine_rate
                    warnings.append(
                        ThresholdWarning(
                            severity="CRITICAL",
                            category="OVERDUE",
                            entity_id=txn.record_id,
                            message=(
                                f"{txn.record_id}: '{book_title}' held by {member_name} is {delta} days overdue "
                                f"(Est. fine: {est_fine:.2f})."
                            ),
                        )
                    )
                elif delta > 0:
                    est_fine = delta * self.config.daily_fine_rate
                    warnings.append(
                        ThresholdWarning(
                            severity="WARNING",
                            category="OVERDUE",
                            entity_id=txn.record_id,
                            message=(
                                f"{txn.record_id}: '{book_title}' held by {member_name} is {delta} day(s) overdue "
                                f"(Est. fine: {est_fine:.2f})."
                            ),
                        )
                    )
                elif -2 <= delta <= 0:
                    days_left = abs(delta)
                    when_text = "today" if days_left == 0 else f"in {days_left} day(s)"
                    warnings.append(
                        ThresholdWarning(
                            severity="WARNING",
                            category="DUE_SOON",
                            entity_id=txn.record_id,
                            message=f"{txn.record_id}: '{book_title}' ({member_name}) is due {when_text}.",
                        )
                    )

        # 2. Stock depletion & inventory anomalies
        for book in sorted(self.state.books.values(), key=lambda b: b.book_id):
            if book.available_copies < 0 or book.available_copies > book.total_copies:
                warnings.append(
                    ThresholdWarning(
                        severity="ANOMALY",
                        category="INTEGRITY",
                        entity_id=book.book_id,
                        message=(
                            f"Book {book.book_id} ('{book.title}') has anomalous stock "
                            f"({book.available_copies}/{book.total_copies})."
                        ),
                    )
                )
            elif book.available_copies == 0:
                warnings.append(
                    ThresholdWarning(
                        severity="CRITICAL",
                        category="STOCK",
                        entity_id=book.book_id,
                        message=f"Book {book.book_id} ('{book.title}') is out of stock (0/{book.total_copies} available).",
                    )
                )
            elif book.available_copies <= self.config.low_stock_threshold:
                warnings.append(
                    ThresholdWarning(
                        severity="WARNING",
                        category="STOCK",
                        entity_id=book.book_id,
                        message=f"Book {book.book_id} ('{book.title}') is low on stock ({book.available_copies}/{book.total_copies} left).",
                    )
                )

        # 3. Member loan cap alerts
        for member in sorted(self.state.members.values(), key=lambda m: m.member_id):
            active_count = self.get_member_active_loan_count(member.member_id)
            if active_count > member.max_loans:
                warnings.append(
                    ThresholdWarning(
                        severity="ANOMALY",
                        category="LOAN_LIMIT",
                        entity_id=member.member_id,
                        message=(
                            f"Member {member.member_id} ({member.name}) exceeds loan cap "
                            f"({active_count}/{member.max_loans})."
                        ),
                    )
                )
            elif active_count == member.max_loans:
                warnings.append(
                    ThresholdWarning(
                        severity="WARNING",
                        category="LOAN_LIMIT",
                        entity_id=member.member_id,
                        message=(
                            f"Member {member.member_id} ({member.name}) is at max loan limit "
                            f"({active_count}/{member.max_loans})."
                        ),
                    )
                )

        severity_order = {"ANOMALY": 0, "CRITICAL": 1, "WARNING": 2}
        return sorted(warnings, key=lambda w: (severity_order.get(w.severity, 9), w.entity_id))
