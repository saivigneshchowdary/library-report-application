"""Bulk CSV import (with row-by-row error logs) and multi-format report exports."""

import csv
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

from src.exceptions import LibraryAppError, ValidationError
from src.models import Book, Member
from src.services.analytics_service import AnalyticsService
from src.services.library_service import LibraryService
from src.services.validators import (
    sanitize_text,
    validate_email,
    validate_isbn,
    validate_membership_type,
    validate_phone,
    validate_positive_int,
    validate_publication_year,
    validate_safe_export_filename,
    validate_shelf_location,
)


@dataclass(frozen=True)
class BulkImportResult:
    """Summary of a bulk CSV ingestion run including error log path."""

    entity_type: str
    source_file: Path
    total_rows: int
    imported_count: int
    skipped_count: int
    errors: list[str]
    error_log_path: Path | None


class ImportExportService:
    """Handles multi-format executive exports and validated legacy CSV imports."""

    def __init__(
        self,
        library_service: LibraryService,
        analytics_service: AnalyticsService,
    ) -> None:
        self.library_service = library_service
        self.analytics_service = analytics_service

    # ------------------------------------------------------------------
    # Stretch Feature: Bulk CSV Dataset Import with Row-by-Row Error Logs
    # ------------------------------------------------------------------
    def bulk_import_books(self, csv_path: Path) -> BulkImportResult:
        """Ingest books from a legacy CSV file, logging row-level validation errors."""
        source = Path(csv_path).expanduser().resolve()
        if not source.exists() or not source.is_file():
            raise ValidationError(f"CSV file not found: '{csv_path}'.")
        if source.suffix.lower() != ".csv":
            raise ValidationError("Bulk import requires a '.csv' file.")

        required_columns = {"isbn", "title", "author", "category", "publication_year", "total_copies"}
        errors: list[str] = []
        imported = 0
        total_rows = 0

        existing_isbns = {book.isbn for book in self.library_service.state.books.values()}
        existing_ids = set(self.library_service.state.books.keys())

        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ValidationError("CSV file is empty or missing a header row.")
            header_set = {col.strip().lower() for col in reader.fieldnames if col}
            missing = sorted(required_columns - header_set)
            if missing:
                raise ValidationError(
                    f"CSV is missing required columns: {', '.join(missing)}."
                )

            for row_num, raw_row in enumerate(reader, start=2):
                total_rows += 1
                normalized = {
                    (k.strip().lower() if k else ""): (v.strip() if v else "")
                    for k, v in raw_row.items()
                }
                try:
                    isbn = validate_isbn(normalized.get("isbn", ""))
                    if isbn in existing_isbns:
                        raise ValidationError(f"Duplicate ISBN '{isbn}' already in catalog/batch.")

                    title = sanitize_text(normalized.get("title", ""), "Title", max_length=140)
                    author = sanitize_text(normalized.get("author", ""), "Author", min_length=2, max_length=100)
                    category = sanitize_text(normalized.get("category", ""), "Category", min_length=2, max_length=60)
                    pub_year = validate_publication_year(normalized.get("publication_year", ""))
                    total_copies = validate_positive_int(
                        normalized.get("total_copies", ""),
                        "Total Copies",
                        min_value=1,
                        max_value=500,
                    )
                    avail_raw = normalized.get("available_copies", "")
                    available_copies = (
                        validate_positive_int(
                            avail_raw,
                            "Available Copies",
                            min_value=0,
                            max_value=total_copies,
                        )
                        if avail_raw
                        else total_copies
                    )
                    shelf = validate_shelf_location(normalized.get("shelf_location", "") or "GEN-A1")

                    raw_book_id = normalized.get("book_id", "")
                    if raw_book_id:
                        book_id = sanitize_text(raw_book_id, "Book ID", min_length=2, max_length=20).upper()
                        if book_id in existing_ids:
                            raise ValidationError(f"Duplicate Book ID '{book_id}'.")
                    else:
                        book_id = self.library_service._next_id("BK-", existing_ids)

                    book = Book(
                        book_id=book_id,
                        isbn=isbn,
                        title=title,
                        author=author,
                        category=category,
                        publication_year=pub_year,
                        total_copies=total_copies,
                        available_copies=available_copies,
                        shelf_location=shelf,
                    )
                    self.library_service.state.books[book.book_id] = book
                    existing_isbns.add(book.isbn)
                    existing_ids.add(book.book_id)
                    imported += 1
                except LibraryAppError as exc:
                    errors.append(f"Row {row_num}: {exc}")

        if imported > 0:
            self.library_service._persist()

        error_log_path = self._write_import_error_log("books", source, total_rows, imported, errors)
        self.library_service.audit_logger.log(
            "BULK_IMPORT_BOOKS",
            "LIBRARIAN",
            f"File={source.name}, total={total_rows}, imported={imported}, skipped={len(errors)}",
        )
        return BulkImportResult(
            entity_type="books",
            source_file=source,
            total_rows=total_rows,
            imported_count=imported,
            skipped_count=len(errors),
            errors=errors,
            error_log_path=error_log_path,
        )

    def bulk_import_members(self, csv_path: Path) -> BulkImportResult:
        """Ingest members from a legacy CSV file, logging row-level validation errors."""
        source = Path(csv_path).expanduser().resolve()
        if not source.exists() or not source.is_file():
            raise ValidationError(f"CSV file not found: '{csv_path}'.")
        if source.suffix.lower() != ".csv":
            raise ValidationError("Bulk import requires a '.csv' file.")

        required_columns = {"name", "email", "phone", "department"}
        errors: list[str] = []
        imported = 0
        total_rows = 0

        existing_emails = {member.email for member in self.library_service.state.members.values()}
        existing_ids = set(self.library_service.state.members.keys())

        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ValidationError("CSV file is empty or missing a header row.")
            header_set = {col.strip().lower() for col in reader.fieldnames if col}
            missing = sorted(required_columns - header_set)
            if missing:
                raise ValidationError(
                    f"CSV is missing required columns: {', '.join(missing)}."
                )

            for row_num, raw_row in enumerate(reader, start=2):
                total_rows += 1
                normalized = {
                    (k.strip().lower() if k else ""): (v.strip() if v else "")
                    for k, v in raw_row.items()
                }
                try:
                    name = sanitize_text(normalized.get("name", ""), "Member Name", min_length=2, max_length=100)
                    email = validate_email(normalized.get("email", ""))
                    if email in existing_emails:
                        raise ValidationError(f"Duplicate email '{email}' already registered.")
                    phone = validate_phone(normalized.get("phone", ""))
                    department = sanitize_text(normalized.get("department", ""), "Department", min_length=2, max_length=80)
                    tier = validate_membership_type(normalized.get("membership_type", "") or "Student")

                    raw_member_id = normalized.get("member_id", "")
                    if raw_member_id:
                        member_id = sanitize_text(raw_member_id, "Member ID", min_length=2, max_length=20).upper()
                        if member_id in existing_ids:
                            raise ValidationError(f"Duplicate Member ID '{member_id}'.")
                    else:
                        member_id = self.library_service._next_id("MEM-", existing_ids)

                    member = Member(
                        member_id=member_id,
                        name=name,
                        email=email,
                        phone=phone,
                        department=department,
                        membership_type=tier,
                        max_loans=self.library_service.config.max_loans_per_member,
                        active=True,
                    )
                    self.library_service.state.members[member.member_id] = member
                    existing_emails.add(member.email)
                    existing_ids.add(member.member_id)
                    imported += 1
                except LibraryAppError as exc:
                    errors.append(f"Row {row_num}: {exc}")

        if imported > 0:
            self.library_service._persist()

        error_log_path = self._write_import_error_log("members", source, total_rows, imported, errors)
        self.library_service.audit_logger.log(
            "BULK_IMPORT_MEMBERS",
            "LIBRARIAN",
            f"File={source.name}, total={total_rows}, imported={imported}, skipped={len(errors)}",
        )
        return BulkImportResult(
            entity_type="members",
            source_file=source,
            total_rows=total_rows,
            imported_count=imported,
            skipped_count=len(errors),
            errors=errors,
            error_log_path=error_log_path,
        )

    def _write_import_error_log(
        self,
        entity_type: str,
        source: Path,
        total_rows: int,
        imported: int,
        errors: list[str],
    ) -> Path | None:
        """Write a detailed row-by-row import error log when any row fails validation."""
        if not errors:
            return None
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_path = self.library_service.repository.logs_dir / f"import_{entity_type}_errors_{timestamp}.log"
        lines = [
            f"Bulk Import Error Log ({entity_type.upper()})",
            f"Source File : {source}",
            f"Timestamp   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Rows Read   : {total_rows}",
            f"Imported    : {imported}",
            f"Skipped     : {len(errors)}",
            "-" * 72,
            *errors,
        ]
        log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return log_path

    # ------------------------------------------------------------------
    # Stretch Feature: Multi-Format Summary Exports (MD, CSV, Audit TXT)
    # ------------------------------------------------------------------
    def export_markdown_summary(
        self,
        filename: str | None = None,
        reference_date: date | None = None,
    ) -> Path:
        """Export a structured Markdown executive report to exports/."""
        summary = self.analytics_service.generate_executive_summary(reference_date)
        target_name = (
            validate_safe_export_filename(filename, ".md")
            if filename
            else f"executive_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        )
        destination = self.library_service.repository.exports_dir / target_name

        lines = [
            "# CampusSolve — Library Executive Summary Report",
            "",
            f"- **Report Date:** {summary.generated_date}",
            f"- **Operational Health Status:** `{summary.health_status}`",
            "",
            "## 1. Key Performance Indicators",
            "",
            "| Metric | Value |",
            "| --- | ---: |",
            f"| Catalog Titles | {summary.total_titles} |",
            f"| Total Copies / Available / Issued | {summary.total_copies} / {summary.available_copies} / {summary.issued_copies} |",
            f"| Collection Utilization Rate | {summary.utilization_rate_pct:.2f}% |",
            f"| Members (Active / Total) | {summary.active_members} / {summary.total_members} |",
            f"| Avg Active Loans per Active Member | {summary.avg_loans_per_active_member:.2f} |",
            f"| Total Transactions | {summary.total_transactions} |",
            f"| Active Loans (Overdue) | {summary.active_loans} ({summary.overdue_loans} overdue) |",
            f"| Return Completion Rate | {summary.return_rate_pct:.2f}% |",
            f"| On-Time Return Rate | {summary.on_time_return_rate_pct:.2f}% |",
            f"| Average Overdue Days (Late Loans) | {summary.avg_overdue_days:.2f} |",
            f"| Total Fines Collected | {summary.total_fines_collected:.2f} |",
            f"| Pending Estimated Fines | {summary.pending_estimated_fines:.2f} |",
            "",
            "## 2. Category Inventory & Circulation",
            "",
            "| Category | Titles | Total Copies | Available | Issued | Historical Loans |",
            "| --- | ---: | ---: | ---: | ---: | ---: |",
        ]
        for cat in summary.category_breakdown:
            lines.append(
                f"| {cat.category} | {cat.title_count} | {cat.total_copies} | "
                f"{cat.available_copies} | {cat.issued_copies} | {cat.historical_loans} |"
            )

        lines.extend(["", "## 3. Top Borrowed Books", ""])
        if summary.top_borrowed_books:
            lines.append("| Rank | Book ID | Title | Total Loans |")
            lines.append("| ---: | --- | --- | ---: |")
            for idx, (book_id, title, count) in enumerate(summary.top_borrowed_books, start=1):
                lines.append(f"| {idx} | {book_id} | {title} | {count} |")
        else:
            lines.append("_No loan records available._")

        lines.extend(["", "## 4. Threshold Warning Indicators", ""])
        if summary.warnings:
            for warn in summary.warnings:
                lines.append(f"- **[{warn.severity}] ({warn.category})** {warn.message}")
        else:
            lines.append("_No active warnings or anomalies detected._")

        destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
        self.library_service.audit_logger.log("EXPORT_MARKDOWN", "LIBRARIAN", f"Exported {destination.name}")
        return destination

    def export_csv_summary(
        self,
        filename: str | None = None,
        reference_date: date | None = None,
    ) -> Path:
        """Export standardized KPI and category metrics to a CSV report in exports/."""
        summary = self.analytics_service.generate_executive_summary(reference_date)
        target_name = (
            validate_safe_export_filename(filename, ".csv")
            if filename
            else f"executive_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        )
        destination = self.library_service.repository.exports_dir / target_name

        with destination.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Section", "Metric_or_Category", "Value_1", "Value_2", "Value_3", "Value_4"])
            writer.writerow(["KPI", "Generated Date", summary.generated_date, "", "", ""])
            writer.writerow(["KPI", "Health Status", summary.health_status, "", "", ""])
            writer.writerow(["KPI", "Catalog Titles", summary.total_titles, "", "", ""])
            writer.writerow(["KPI", "Copies (Total/Avail/Issued)", summary.total_copies, summary.available_copies, summary.issued_copies, ""])
            writer.writerow(["KPI", "Utilization Rate (%)", summary.utilization_rate_pct, "", "", ""])
            writer.writerow(["KPI", "Active / Total Members", summary.active_members, summary.total_members, "", ""])
            writer.writerow(["KPI", "Active / Overdue Loans", summary.active_loans, summary.overdue_loans, "", ""])
            writer.writerow(["KPI", "Return Rate (%)", summary.return_rate_pct, "", "", ""])
            writer.writerow(["KPI", "Fines Collected / Pending", summary.total_fines_collected, summary.pending_estimated_fines, "", ""])
            for cat in summary.category_breakdown:
                writer.writerow([
                    "CATEGORY",
                    cat.category,
                    f"titles={cat.title_count}",
                    f"total={cat.total_copies}",
                    f"available={cat.available_copies}",
                    f"loans={cat.historical_loans}",
                ])
            for warn in summary.warnings:
                writer.writerow(["WARNING", warn.severity, warn.category, warn.entity_id, warn.message, ""])

        self.library_service.audit_logger.log("EXPORT_CSV", "LIBRARIAN", f"Exported {destination.name}")
        return destination

    def export_audit_log_report(self, filename: str | None = None) -> Path:
        """Export the full plain-text audit trail to exports/."""
        target_name = (
            validate_safe_export_filename(filename, ".txt")
            if filename
            else f"audit_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        )
        destination = self.library_service.repository.exports_dir / target_name
        self.library_service.audit_logger.export_log(destination)
        self.library_service.audit_logger.log("EXPORT_AUDIT_LOG", "LIBRARIAN", f"Exported {destination.name}")
        return destination
