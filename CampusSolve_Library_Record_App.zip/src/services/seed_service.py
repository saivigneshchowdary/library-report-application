"""Deterministic sample dataset seeder with normal, boundary, and edge-case records."""

import csv
from datetime import date, timedelta
from pathlib import Path

from src.models import Book, LoanStatus, LoanTransaction, Member
from src.repositories import LibraryState
from src.services.library_service import LibraryService


class SeedService:
    """Seeds 48 realistic records (books, members, transactions) and a sample CSV."""

    @staticmethod
    def build_sample_state(reference_date: date | None = None) -> LibraryState:
        """Create 18 books, 12 members, and 18 loan transactions covering edge cases."""
        today = reference_date or date.today()

        books_list = [
            Book("BK-001", "9780132350884", "Clean Code", "Robert C. Martin", "Software Engineering", 2008, 4, 2, "SE-A1"),
            Book("BK-002", "9780201633610", "Design Patterns", "Erich Gamma", "Software Engineering", 1994, 3, 1, "SE-A2"),
            Book("BK-003", "9780131103627", "The C Programming Language", "Brian W. Kernighan", "Programming", 1988, 5, 4, "PR-B1"),
            Book("BK-004", "9780262033848", "Introduction to Algorithms", "Thomas H. Cormen", "Algorithms", 2009, 3, 0, "AL-C1"),
            Book("BK-005", "9781491957660", "Python for Data Analysis", "Wes McKinney", "Data Science", 2017, 4, 3, "DS-D1"),
            Book("BK-006", "9781449355739", "Learning Python", "Mark Lutz", "Programming", 2013, 6, 4, "PR-B2"),
            Book("BK-007", "9780134685991", "Effective Java", "Joshua Bloch", "Programming", 2018, 2, 1, "PR-B3"),
            Book("BK-008", "9780596007126", "Head First Design Patterns", "Eric Freeman", "Software Engineering", 2004, 3, 2, "SE-A3"),
            Book("BK-009", "9780321125217", "Domain-Driven Design", "Eric Evans", "Architecture", 2003, 2, 1, "AR-E1"),
            Book("BK-010", "9780134494166", "Clean Architecture", "Robert C. Martin", "Architecture", 2017, 3, 2, "AR-E2"),
            Book("BK-011", "9781492032649", "Hands-On Machine Learning", "Aurelien Geron", "Data Science", 2019, 3, 1, "DS-D2"),
            Book("BK-012", "9780262533058", "Structure and Interpretation of Computer Programs", "Harold Abelson", "Algorithms", 1996, 2, 2, "AL-C2"),
            Book("BK-013", "9780136042594", "Artificial Intelligence: A Modern Approach", "Stuart Russell", "AI & Robotics", 2009, 3, 2, "AI-F1"),
            Book("BK-014", "9781593279288", "Python Crash Course", "Eric Matthes", "Programming", 2019, 5, 3, "PR-B4"),
            Book("BK-015", "9780321573513", "Algorithms (4th Edition)", "Robert Sedgewick", "Algorithms", 2011, 2, 1, "AL-C3"),
            Book("BK-016", "9781491950357", "Building Microservices", "Sam Newman", "Architecture", 2015, 2, 2, "AR-E3"),
            Book("BK-017", "9780132126953", "Computer Networks", "Andrew S. Tanenbaum", "Networking", 2010, 4, 3, "NW-G1"),
            Book("BK-018", "9780073523323", "Database System Concepts", "Abraham Silberschatz", "Databases", 2010, 3, 2, "DB-H1"),
        ]

        members_list = [
            Member("MEM-001", "Aarav Sharma", "aarav.sharma@campus.edu", "9876543210", "Computer Science", "Student", 5, (today - timedelta(days=180)).isoformat(), True),
            Member("MEM-002", "Priya Nair", "priya.nair@campus.edu", "9876543211", "Information Technology", "Student", 5, (today - timedelta(days=150)).isoformat(), True),
            Member("MEM-003", "Dr. Vikram Rao", "vikram.rao@campus.edu", "9876543212", "Computer Science", "Faculty", 5, (today - timedelta(days=365)).isoformat(), True),
            Member("MEM-004", "Ananya Iyer", "ananya.iyer@campus.edu", "9876543213", "Data Science", "Researcher", 5, (today - timedelta(days=120)).isoformat(), True),
            Member("MEM-005", "Rohan Kulkarni", "rohan.kulkarni@campus.edu", "9876543214", "Electronics", "Student", 5, (today - timedelta(days=90)).isoformat(), True),
            Member("MEM-006", "Meera Krishnan", "meera.krishnan@campus.edu", "9876543215", "Library Ops", "Staff", 5, (today - timedelta(days=300)).isoformat(), True),
            Member("MEM-007", "Siddharth Verma", "siddharth.verma@campus.edu", "9876543216", "Computer Science", "Student", 5, (today - timedelta(days=60)).isoformat(), True),
            Member("MEM-008", "Kavya Menon", "kavya.menon@campus.edu", "9876543217", "Mathematics", "Student", 5, (today - timedelta(days=45)).isoformat(), True),
            Member("MEM-009", "Prof. Arjun Deshmukh", "arjun.deshmukh@campus.edu", "9876543218", "AI & Robotics", "Faculty", 5, (today - timedelta(days=400)).isoformat(), True),
            Member("MEM-010", "Neha Gupta", "neha.gupta@campus.edu", "9876543219", "Information Technology", "Student", 5, (today - timedelta(days=30)).isoformat(), True),
            Member("MEM-011", "Devansh Patel", "devansh.patel@campus.edu", "9876543220", "Mechanical", "Student", 5, (today - timedelta(days=200)).isoformat(), False),
            Member("MEM-012", "Sneha Chatterjee", "sneha.chatterjee@campus.edu", "9876543221", "Data Science", "Researcher", 5, (today - timedelta(days=75)).isoformat(), True),
        ]

        # 18 Transactions: returned on time, returned late, active on-time, due soon, overdue, and 5-loan limit boundary (MEM-001 holds 5 active loans)
        txns_list = [
            # Active loans for MEM-001 (5 loans -> triggers LOAN_LIMIT warning!)
            LoanTransaction("TXN-001", "BK-001", "MEM-001", (today - timedelta(days=25)).isoformat(), (today - timedelta(days=11)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Overdue >7 days critical"),
            LoanTransaction("TXN-002", "BK-002", "MEM-001", (today - timedelta(days=17)).isoformat(), (today - timedelta(days=3)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Overdue 3 days warning"),
            LoanTransaction("TXN-003", "BK-004", "MEM-001", (today - timedelta(days=13)).isoformat(), (today + timedelta(days=1)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Due tomorrow"),
            LoanTransaction("TXN-004", "BK-007", "MEM-001", (today - timedelta(days=5)).isoformat(), (today + timedelta(days=9)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Active normal"),
            LoanTransaction("TXN-005", "BK-009", "MEM-001", (today - timedelta(days=3)).isoformat(), (today + timedelta(days=11)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Active normal"),
            # Additional active & overdue loans matching remaining issued copy counts
            LoanTransaction("TXN-006", "BK-001", "MEM-002", (today - timedelta(days=10)).isoformat(), (today + timedelta(days=4)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, ""),
            LoanTransaction("TXN-007", "BK-002", "MEM-003", (today - timedelta(days=20)).isoformat(), (today - timedelta(days=6)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Faculty overdue"),
            LoanTransaction("TXN-008", "BK-003", "MEM-004", (today - timedelta(days=6)).isoformat(), (today + timedelta(days=8)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, ""),
            LoanTransaction("TXN-009", "BK-004", "MEM-002", (today - timedelta(days=14)).isoformat(), today.isoformat(), None, LoanStatus.ISSUED.value, 0.0, 1, "Due today"),
            LoanTransaction("TXN-010", "BK-004", "MEM-005", (today - timedelta(days=4)).isoformat(), (today + timedelta(days=10)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Last copy issued"),
            LoanTransaction("TXN-011", "BK-005", "MEM-006", (today - timedelta(days=8)).isoformat(), (today + timedelta(days=6)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, ""),
            LoanTransaction("TXN-012", "BK-006", "MEM-007", (today - timedelta(days=2)).isoformat(), (today + timedelta(days=12)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, ""),
            LoanTransaction("TXN-013", "BK-006", "MEM-008", (today - timedelta(days=1)).isoformat(), (today + timedelta(days=13)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, ""),
            LoanTransaction("TXN-014", "BK-008", "MEM-009", (today - timedelta(days=7)).isoformat(), (today + timedelta(days=7)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, ""),
            LoanTransaction("TXN-015", "BK-010", "MEM-012", (today - timedelta(days=12)).isoformat(), (today + timedelta(days=2)).isoformat(), None, LoanStatus.ISSUED.value, 0.0, 0, "Due in 2 days"),
            # Historical returned loans (including on-time and late with fines)
            LoanTransaction("TXN-016", "BK-001", "MEM-003", (today - timedelta(days=60)).isoformat(), (today - timedelta(days=46)).isoformat(), (today - timedelta(days=48)).isoformat(), LoanStatus.RETURNED.value, 0.0, 0, "Returned early"),
            LoanTransaction("TXN-017", "BK-004", "MEM-004", (today - timedelta(days=50)).isoformat(), (today - timedelta(days=36)).isoformat(), (today - timedelta(days=32)).isoformat(), LoanStatus.RETURNED.value, 20.0, 0, "Returned 4 days late"),
            LoanTransaction("TXN-018", "BK-011", "MEM-010", (today - timedelta(days=40)).isoformat(), (today - timedelta(days=26)).isoformat(), (today - timedelta(days=26)).isoformat(), LoanStatus.RETURNED.value, 0.0, 0, "Returned on due date"),
        ]

        # Recompute available_copies strictly from active loans for 100% consistency
        books = {book.book_id: book for book in books_list}
        for book in books.values():
            active_for_book = sum(
                1 for txn in txns_list
                if txn.book_id == book.book_id and txn.status == LoanStatus.ISSUED.value
            )
            book.available_copies = max(0, book.total_copies - active_for_book)

        return LibraryState(
            books=books,
            members={member.member_id: member for member in members_list},
            transactions={txn.record_id: txn for txn in txns_list},
        )

    @classmethod
    def seed_application(cls, library_service: LibraryService, overwrite: bool = False) -> bool:
        """Populate repository with sample data if empty or overwrite=True."""
        state = library_service.state
        has_data = bool(state.books or state.members or state.transactions)
        if has_data and not overwrite:
            return False

        seeded_state = cls.build_sample_state()
        library_service.state = seeded_state
        library_service._persist()
        library_service.audit_logger.log(
            "SEED_DATASET",
            "SYSTEM",
            f"Seeded {len(seeded_state.books)} books, {len(seeded_state.members)} members, "
            f"{len(seeded_state.transactions)} transactions.",
        )
        cls.write_sample_legacy_import_csv(library_service.repository.data_dir / "sample_legacy_import.csv")
        return True

    @staticmethod
    def write_sample_legacy_import_csv(destination: Path) -> Path:
        """Create a sample legacy CSV with valid and invalid rows for bulk import demos."""
        rows = [
            ["isbn", "title", "author", "category", "publication_year", "total_copies", "shelf_location"],
            ["9780134757599", "Refactoring (2nd Edition)", "Martin Fowler", "Software Engineering", "2018", "3", "SE-A4"],
            ["9781492078005", "Designing Data-Intensive Applications", "Martin Kleppmann", "Databases", "2017", "4", "DB-H2"],
            ["9780201485677", "Refactoring (1st Edition)", "Martin Fowler", "Software Engineering", "1999", "2", "SE-A5"],
            # Intentionally invalid rows to demonstrate row-by-row validation & error logging:
            ["1234567890", "Broken Checksum Book", "Test Author", "Testing", "2020", "2", "TS-Z1"],
            ["9780132350884", "Duplicate Clean Code", "Robert Martin", "Software Engineering", "2008", "2", "SE-A1"],
            ["9780135957059", "The Pragmatic Programmer", "David Thomas", "Software Engineering", "2019", "0", "SE-A6"],
            ["9780596517748", "JavaScript: The Good Parts", "Douglas Crockford", "Programming", "1200", "2", "PR-B9"],
        ]
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerows(rows)
        return destination
