"""Structured plain-text audit trail logger for library operations."""

from datetime import datetime
from pathlib import Path


class AuditLogger:
    """Appends timestamped operational events to a persistent plain-text log."""

    def __init__(self, log_path: Path) -> None:
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, action: str, actor: str, details: str) -> None:
        """Write a single formatted audit record to disk."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sanitized_details = details.replace("\r", " ").replace("\n", " ").strip()
        entry = f"[{timestamp}] | {action:<18} | {actor:<14} | {sanitized_details}\n"
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(entry)

    def read_recent(self, limit: int = 50) -> list[str]:
        """Return the most recent audit log lines, newest last."""
        if not self.log_path.exists():
            return []
        with self.log_path.open("r", encoding="utf-8") as handle:
            lines = [line.rstrip("\n") for line in handle if line.strip()]
        return lines[-limit:] if limit > 0 else lines

    def export_log(self, destination: Path) -> Path:
        """Copy the audit trail to an external plain-text report file."""
        destination.parent.mkdir(parents=True, exist_ok=True)
        lines = self.read_recent(limit=0)
        header = [
            "========================================================================",
            "CampusSolve — Library Record Application | Audit Trail Export",
            f"Generated At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Total Events: {len(lines)}",
            "========================================================================",
            "",
        ]
        content = "\n".join(header + lines) + "\n"
        destination.write_text(content, encoding="utf-8")
        return destination
