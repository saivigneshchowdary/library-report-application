"""Local JSON and CSV persistence repository with schema validation and recovery."""

from dataclasses import dataclass, field
from datetime import datetime
import csv
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

from src.config import DEFAULT_CONFIG, LibraryConfig
from src.exceptions import PersistenceError
from src.models import Book, LoanTransaction, Member


BOOK_CSV_FIELDS = [
    "book_id",
    "isbn",
    "title",
    "author",
    "category",
    "publication_year",
    "total_copies",
    "available_copies",
    "shelf_location",
    "added_at",
]

MEMBER_CSV_FIELDS = [
    "member_id",
    "name",
    "email",
    "phone",
    "department",
    "membership_type",
    "max_loans",
    "joined_at",
    "active",
]

TRANSACTION_CSV_FIELDS = [
    "record_id",
    "book_id",
    "member_id",
    "issue_date",
    "due_date",
    "return_date",
    "status",
    "fine_amount",
    "renewal_count",
    "notes",
]

_CSV_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _neutralize_csv_cell(value: Any) -> str:
    """Prevent spreadsheet formula injection when exporting CSV cells."""
    if value is None:
        return ""
    text = str(value)
    if text and text[0] in _CSV_FORMULA_PREFIXES:
        return "'" + text
    return text


def _restore_csv_cell(value: str) -> str:
    """Reverse leading quote added by CSV formula neutralization on read-back."""
    if len(value) >= 2 and value[0] == "'" and value[1] in _CSV_FORMULA_PREFIXES:
        return value[1:]
    return value


@dataclass
class LibraryState:
    """In-memory container representing all persisted library collections."""

    books: dict[str, Book] = field(default_factory=dict)
    members: dict[str, Member] = field(default_factory=dict)
    transactions: dict[str, LoanTransaction] = field(default_factory=dict)
    schema_version: str = "2.0"
    last_updated: str = ""
    recovery_warnings: list[str] = field(default_factory=list)


class LibraryRepository:
    """Manages atomic JSON persistence, synchronized CSV exports, and backups."""

    def __init__(self, base_dir: Path, config: LibraryConfig = DEFAULT_CONFIG) -> None:
        self.base_dir = Path(base_dir)
        self.config = config
        self.data_dir = self.base_dir / config.data_dir_name
        self.exports_dir = self.base_dir / config.exports_dir_name
        self.backups_dir = self.base_dir / config.backups_dir_name
        self.logs_dir = self.base_dir / config.logs_dir_name

        self.state_path = self.data_dir / config.state_filename
        self.books_csv_path = self.data_dir / config.books_csv_filename
        self.members_csv_path = self.data_dir / config.members_csv_filename
        self.transactions_csv_path = self.data_dir / config.transactions_csv_filename

        self.ensure_directories()

    def ensure_directories(self) -> None:
        """Create required storage directories if they do not already exist."""
        for directory in (self.data_dir, self.exports_dir, self.backups_dir, self.logs_dir):
            directory.mkdir(parents=True, exist_ok=True)

    def load_state(self) -> LibraryState:
        """Load state from JSON, recovering cleanly from missing or corrupted files."""
        self.ensure_directories()
        warnings: list[str] = []

        if not self.state_path.exists():
            # Attempt fallback bootstrap from CSVs if present; otherwise create clean template.
            if self._any_csv_exists():
                state = self._load_from_csv_fallback(warnings)
                self.save_state(state)
                return state
            empty_state = LibraryState(last_updated=datetime.now().isoformat(timespec="seconds"))
            self.save_state(empty_state)
            warnings.append(
                f"Initialized new storage template at '{self.state_path.name}'."
            )
            empty_state.recovery_warnings = warnings
            return empty_state

        try:
            raw_text = self.state_path.read_text(encoding="utf-8")
            if not raw_text.strip():
                raise json.JSONDecodeError("Empty JSON file", raw_text, 0)
            payload = json.loads(raw_text)
            state = self._parse_json_payload(payload)
            state.recovery_warnings = warnings
            return state
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            backup_name = self._quarantine_corrupted_file(self.state_path)
            warnings.append(
                f"Recovered from corrupted JSON ({type(exc).__name__}). "
                f"Quarantined original to '{backup_name}' and initialized clean state."
            )
            clean_state = LibraryState(
                last_updated=datetime.now().isoformat(timespec="seconds"),
                recovery_warnings=warnings,
            )
            self.save_state(clean_state)
            return clean_state
        except OSError as exc:
            raise PersistenceError(f"Unable to read state file '{self.state_path}': {exc}") from exc

    def save_state(self, state: LibraryState) -> None:
        """Atomically persist state to JSON and synchronize CSV mirror files."""
        self.ensure_directories()
        state.last_updated = datetime.now().isoformat(timespec="seconds")

        payload = {
            "schema_version": state.schema_version,
            "last_updated": state.last_updated,
            "books": [book.to_dict() for book in state.books.values()],
            "members": [member.to_dict() for member in state.members.values()],
            "transactions": [txn.to_dict() for txn in state.transactions.values()],
        }

        self._atomic_write_text(
            self.state_path,
            json.dumps(payload, indent=2, ensure_ascii=False),
        )
        self._write_csv(
            self.books_csv_path,
            BOOK_CSV_FIELDS,
            [book.to_dict() for book in state.books.values()],
        )
        self._write_csv(
            self.members_csv_path,
            MEMBER_CSV_FIELDS,
            [member.to_dict() for member in state.members.values()],
        )
        self._write_csv(
            self.transactions_csv_path,
            TRANSACTION_CSV_FIELDS,
            [txn.to_dict() for txn in state.transactions.values()],
        )

    def create_backup(self, label: str = "manual") -> Path:
        """Write a timestamped JSON snapshot to the backups directory."""
        self.ensure_directories()
        if not self.state_path.exists():
            raise PersistenceError("Cannot create backup because no state file exists yet.")
        safe_label = "".join(ch for ch in label if ch.isalnum() or ch in ("-", "_")) or "manual"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = self.backups_dir / f"library_backup_{safe_label}_{timestamp}.json"
        shutil.copy2(self.state_path, backup_path)
        return backup_path

    def list_backups(self) -> list[Path]:
        """Return available backup JSON files ordered newest first."""
        self.ensure_directories()
        backups = sorted(
            self.backups_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        return backups

    def restore_backup(self, backup_path: Path) -> LibraryState:
        """Validate a backup JSON file and promote it to the active library state."""
        resolved_backup = Path(backup_path).resolve()
        if not resolved_backup.exists():
            raise PersistenceError(f"Backup file not found: {resolved_backup}")
        try:
            payload = json.loads(resolved_backup.read_text(encoding="utf-8"))
            restored_state = self._parse_json_payload(payload)
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise PersistenceError(f"Invalid backup file '{resolved_backup.name}': {exc}") from exc

        if self.state_path.exists():
            self.create_backup(label="pre_restore")
        self.save_state(restored_state)
        return restored_state

    def _parse_json_payload(self, payload: Any) -> LibraryState:
        """Validate top-level JSON structure and deserialize all entity collections."""
        if not isinstance(payload, dict):
            raise ValueError("Root JSON payload must be an object.")
        for required_key in ("books", "members", "transactions"):
            if required_key not in payload or not isinstance(payload[required_key], list):
                raise ValueError(f"Missing or invalid '{required_key}' list in JSON schema.")

        books: dict[str, Book] = {}
        for item in payload["books"]:
            if not isinstance(item, dict):
                raise ValueError("Book entry must be a JSON object.")
            book = Book.from_dict(item)
            books[book.book_id] = book

        members: dict[str, Member] = {}
        for item in payload["members"]:
            if not isinstance(item, dict):
                raise ValueError("Member entry must be a JSON object.")
            member = Member.from_dict(item)
            members[member.member_id] = member

        transactions: dict[str, LoanTransaction] = {}
        for item in payload["transactions"]:
            if not isinstance(item, dict):
                raise ValueError("Transaction entry must be a JSON object.")
            txn = LoanTransaction.from_dict(item)
            transactions[txn.record_id] = txn

        return LibraryState(
            books=books,
            members=members,
            transactions=transactions,
            schema_version=str(payload.get("schema_version", "2.0")),
            last_updated=str(payload.get("last_updated", "")),
        )

    def _any_csv_exists(self) -> bool:
        return any(
            path.exists()
            for path in (self.books_csv_path, self.members_csv_path, self.transactions_csv_path)
        )

    def _load_from_csv_fallback(self, warnings: list[str]) -> LibraryState:
        """Reconstruct LibraryState from CSV mirrors when JSON state is missing."""
        books: dict[str, Book] = {}
        members: dict[str, Member] = {}
        transactions: dict[str, LoanTransaction] = {}

        if self.books_csv_path.exists():
            for row in self._read_csv(self.books_csv_path):
                book = Book.from_dict(row)
                books[book.book_id] = book
        if self.members_csv_path.exists():
            for row in self._read_csv(self.members_csv_path):
                member = Member.from_dict(row)
                members[member.member_id] = member
        if self.transactions_csv_path.exists():
            for row in self._read_csv(self.transactions_csv_path):
                txn = LoanTransaction.from_dict(row)
                transactions[txn.record_id] = txn

        warnings.append(
            "JSON state file was missing; reconstructed state from CSV storage files."
        )
        return LibraryState(
            books=books,
            members=members,
            transactions=transactions,
            recovery_warnings=warnings,
        )

    def _quarantine_corrupted_file(self, corrupted_path: Path) -> str:
        """Move a corrupted storage file into backups/ so data can be inspected."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        quarantine_name = f"corrupted_{corrupted_path.stem}_{timestamp}{corrupted_path.suffix}"
        quarantine_path = self.backups_dir / quarantine_name
        shutil.copy2(corrupted_path, quarantine_path)
        return quarantine_name

    def _atomic_write_text(self, target_path: Path, content: str) -> None:
        """Write text to a temporary file in the same directory and replace atomically."""
        fd, tmp_name = tempfile.mkstemp(
            dir=str(target_path.parent),
            prefix=f".{target_path.stem}_",
            suffix=".tmp",
        )
        tmp_path = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(content)
            os.replace(tmp_path, target_path)
        except OSError as exc:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise PersistenceError(f"Failed to write '{target_path}': {exc}") from exc

    def _write_csv(
        self,
        target_path: Path,
        fieldnames: list[str],
        rows: list[dict[str, Any]],
    ) -> None:
        """Write rows to a CSV file atomically with formula-injection protection."""
        fd, tmp_name = tempfile.mkstemp(
            dir=str(target_path.parent),
            prefix=f".{target_path.stem}_",
            suffix=".tmp",
        )
        tmp_path = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                for row in rows:
                    sanitized = {
                        key: _neutralize_csv_cell(row.get(key, ""))
                        for key in fieldnames
                    }
                    writer.writerow(sanitized)
            os.replace(tmp_path, target_path)
        except OSError as exc:
            if tmp_path.exists():
                tmp_path.unlink(missing_ok=True)
            raise PersistenceError(f"Failed to write CSV '{target_path}': {exc}") from exc

    @staticmethod
    def _read_csv(source_path: Path) -> list[dict[str, str]]:
        """Read a CSV file into a list of dictionaries with formula unescaping."""
        with source_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            return [
                {k: _restore_csv_cell(v or "") for k, v in row.items() if k is not None}
                for row in reader
            ]
