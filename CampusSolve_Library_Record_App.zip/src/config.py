"""Application-wide configuration constants and library policy settings."""

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class LibraryConfig:
    """Immutable configuration governing library rules and storage paths."""

    app_name: str = "CampusSolve — Library Record Application"
    version: str = "2.0.0"
    max_loans_per_member: int = 5
    default_loan_days: int = 14
    max_renewal_days: int = 7
    daily_fine_rate: float = 5.0
    low_stock_threshold: int = 1
    page_size: int = 10
    min_publication_year: int = 1450
    max_publication_year: int = 2100

    # Directory layout relative to project root
    data_dir_name: str = "data"
    exports_dir_name: str = "exports"
    backups_dir_name: str = "backups"
    logs_dir_name: str = "logs"

    state_filename: str = "library_state.json"
    books_csv_filename: str = "books.csv"
    members_csv_filename: str = "members.csv"
    transactions_csv_filename: str = "transactions.csv"
    audit_log_filename: str = "audit_trail.log"


DEFAULT_CONFIG = LibraryConfig()


def resolve_project_root() -> Path:
    """Return the root directory of the application."""
    return Path(__file__).resolve().parent.parent
