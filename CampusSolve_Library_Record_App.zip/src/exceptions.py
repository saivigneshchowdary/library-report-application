"""Custom domain, validation, and persistence exceptions."""


class LibraryAppError(Exception):
    """Base exception for all Library Record Application errors."""


class ValidationError(LibraryAppError):
    """Raised when user input or imported data violates domain constraints."""


class NotFoundError(LibraryAppError):
    """Raised when a requested book, member, or transaction does not exist."""


class DuplicateRecordError(LibraryAppError):
    """Raised when attempting to create a record with a conflicting unique key."""


class BusinessRuleError(LibraryAppError):
    """Raised when an operation violates library policy (e.g., loan limit, no stock)."""


class PersistenceError(LibraryAppError):
    """Raised when reading, validating, or writing persistent storage fails."""
